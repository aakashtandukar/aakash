<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-01-08 06:25:28 --> Config Class Initialized
DEBUG - 2013-01-08 06:25:28 --> Hooks Class Initialized
DEBUG - 2013-01-08 06:25:28 --> Utf8 Class Initialized
DEBUG - 2013-01-08 06:25:28 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 06:25:28 --> URI Class Initialized
DEBUG - 2013-01-08 06:25:28 --> Router Class Initialized
DEBUG - 2013-01-08 06:25:28 --> No URI present. Default controller set.
DEBUG - 2013-01-08 06:25:28 --> Output Class Initialized
DEBUG - 2013-01-08 06:25:28 --> Security Class Initialized
DEBUG - 2013-01-08 06:25:28 --> Input Class Initialized
DEBUG - 2013-01-08 06:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 06:25:28 --> Language Class Initialized
DEBUG - 2013-01-08 06:25:28 --> Loader Class Initialized
DEBUG - 2013-01-08 06:25:28 --> Helper loaded: url_helper
DEBUG - 2013-01-08 06:25:28 --> Controller Class Initialized
DEBUG - 2013-01-08 06:25:28 --> Model Class Initialized
DEBUG - 2013-01-08 06:25:28 --> Model Class Initialized
DEBUG - 2013-01-08 06:25:28 --> Database Driver Class Initialized
DEBUG - 2013-01-08 06:25:28 --> File loaded: application/views/home.php
DEBUG - 2013-01-08 06:25:28 --> Final output sent to browser
DEBUG - 2013-01-08 06:25:28 --> Total execution time: 0.9693
DEBUG - 2013-01-08 06:25:30 --> Config Class Initialized
DEBUG - 2013-01-08 06:25:30 --> Hooks Class Initialized
DEBUG - 2013-01-08 06:25:30 --> Utf8 Class Initialized
DEBUG - 2013-01-08 06:25:30 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 06:25:30 --> URI Class Initialized
DEBUG - 2013-01-08 06:25:30 --> Router Class Initialized
DEBUG - 2013-01-08 06:25:30 --> Output Class Initialized
DEBUG - 2013-01-08 06:25:30 --> Security Class Initialized
DEBUG - 2013-01-08 06:25:30 --> Input Class Initialized
DEBUG - 2013-01-08 06:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 06:25:30 --> Language Class Initialized
DEBUG - 2013-01-08 06:25:30 --> Loader Class Initialized
DEBUG - 2013-01-08 06:25:30 --> Helper loaded: url_helper
DEBUG - 2013-01-08 06:25:30 --> Controller Class Initialized
DEBUG - 2013-01-08 06:25:30 --> Model Class Initialized
DEBUG - 2013-01-08 06:25:30 --> Model Class Initialized
DEBUG - 2013-01-08 06:25:30 --> Database Driver Class Initialized
DEBUG - 2013-01-08 06:25:30 --> File loaded: application/views/register.php
DEBUG - 2013-01-08 06:25:30 --> Final output sent to browser
DEBUG - 2013-01-08 06:25:30 --> Total execution time: 0.1939
DEBUG - 2013-01-08 06:25:30 --> Config Class Initialized
DEBUG - 2013-01-08 06:25:30 --> Hooks Class Initialized
DEBUG - 2013-01-08 06:25:30 --> Utf8 Class Initialized
DEBUG - 2013-01-08 06:25:30 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 06:25:30 --> URI Class Initialized
DEBUG - 2013-01-08 06:25:30 --> Router Class Initialized
ERROR - 2013-01-08 06:25:31 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-08 06:25:46 --> Config Class Initialized
DEBUG - 2013-01-08 06:25:46 --> Hooks Class Initialized
DEBUG - 2013-01-08 06:25:46 --> Utf8 Class Initialized
DEBUG - 2013-01-08 06:25:46 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 06:25:46 --> URI Class Initialized
DEBUG - 2013-01-08 06:25:46 --> Router Class Initialized
DEBUG - 2013-01-08 06:25:46 --> Output Class Initialized
DEBUG - 2013-01-08 06:25:46 --> Security Class Initialized
DEBUG - 2013-01-08 06:25:46 --> Input Class Initialized
DEBUG - 2013-01-08 06:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 06:25:46 --> Language Class Initialized
DEBUG - 2013-01-08 06:25:46 --> Loader Class Initialized
DEBUG - 2013-01-08 06:25:46 --> Helper loaded: url_helper
DEBUG - 2013-01-08 06:25:46 --> Controller Class Initialized
DEBUG - 2013-01-08 06:25:46 --> Model Class Initialized
DEBUG - 2013-01-08 06:25:46 --> Model Class Initialized
DEBUG - 2013-01-08 06:25:46 --> Database Driver Class Initialized
DEBUG - 2013-01-08 06:25:46 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-08 06:25:46 --> Final output sent to browser
DEBUG - 2013-01-08 06:25:46 --> Total execution time: 0.2049
DEBUG - 2013-01-08 06:25:46 --> Config Class Initialized
DEBUG - 2013-01-08 06:25:46 --> Hooks Class Initialized
DEBUG - 2013-01-08 06:25:46 --> Utf8 Class Initialized
DEBUG - 2013-01-08 06:25:46 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 06:25:46 --> URI Class Initialized
DEBUG - 2013-01-08 06:25:46 --> Router Class Initialized
ERROR - 2013-01-08 06:25:46 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-08 11:22:54 --> Config Class Initialized
DEBUG - 2013-01-08 11:22:54 --> Hooks Class Initialized
DEBUG - 2013-01-08 11:22:54 --> Utf8 Class Initialized
DEBUG - 2013-01-08 11:22:54 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 11:22:54 --> URI Class Initialized
DEBUG - 2013-01-08 11:22:54 --> Router Class Initialized
DEBUG - 2013-01-08 11:22:54 --> Output Class Initialized
DEBUG - 2013-01-08 11:22:54 --> Security Class Initialized
DEBUG - 2013-01-08 11:22:54 --> Input Class Initialized
DEBUG - 2013-01-08 11:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 11:22:54 --> Language Class Initialized
DEBUG - 2013-01-08 11:22:54 --> Loader Class Initialized
DEBUG - 2013-01-08 11:22:55 --> Helper loaded: url_helper
DEBUG - 2013-01-08 11:22:55 --> Controller Class Initialized
DEBUG - 2013-01-08 11:22:55 --> Model Class Initialized
DEBUG - 2013-01-08 11:22:55 --> Model Class Initialized
DEBUG - 2013-01-08 11:22:55 --> Database Driver Class Initialized
DEBUG - 2013-01-08 11:22:56 --> Final output sent to browser
DEBUG - 2013-01-08 11:22:56 --> Total execution time: 2.5044
DEBUG - 2013-01-08 11:23:06 --> Config Class Initialized
DEBUG - 2013-01-08 11:23:06 --> Hooks Class Initialized
DEBUG - 2013-01-08 11:23:06 --> Utf8 Class Initialized
DEBUG - 2013-01-08 11:23:06 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 11:23:06 --> URI Class Initialized
DEBUG - 2013-01-08 11:23:06 --> Router Class Initialized
DEBUG - 2013-01-08 11:23:06 --> Output Class Initialized
DEBUG - 2013-01-08 11:23:06 --> Security Class Initialized
DEBUG - 2013-01-08 11:23:06 --> Input Class Initialized
DEBUG - 2013-01-08 11:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 11:23:06 --> Language Class Initialized
DEBUG - 2013-01-08 11:23:06 --> Loader Class Initialized
DEBUG - 2013-01-08 11:23:06 --> Helper loaded: url_helper
DEBUG - 2013-01-08 11:23:06 --> Controller Class Initialized
DEBUG - 2013-01-08 11:23:06 --> Model Class Initialized
DEBUG - 2013-01-08 11:23:06 --> Model Class Initialized
DEBUG - 2013-01-08 11:23:06 --> Database Driver Class Initialized
DEBUG - 2013-01-08 11:23:06 --> Final output sent to browser
DEBUG - 2013-01-08 11:23:06 --> Total execution time: 0.1429
DEBUG - 2013-01-08 11:23:53 --> Config Class Initialized
DEBUG - 2013-01-08 11:23:53 --> Hooks Class Initialized
DEBUG - 2013-01-08 11:23:53 --> Utf8 Class Initialized
DEBUG - 2013-01-08 11:23:53 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 11:23:53 --> URI Class Initialized
DEBUG - 2013-01-08 11:23:53 --> Router Class Initialized
DEBUG - 2013-01-08 11:23:53 --> Output Class Initialized
DEBUG - 2013-01-08 11:23:53 --> Security Class Initialized
DEBUG - 2013-01-08 11:23:53 --> Input Class Initialized
DEBUG - 2013-01-08 11:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 11:23:53 --> Language Class Initialized
DEBUG - 2013-01-08 11:23:53 --> Loader Class Initialized
DEBUG - 2013-01-08 11:23:53 --> Helper loaded: url_helper
DEBUG - 2013-01-08 11:23:53 --> Controller Class Initialized
DEBUG - 2013-01-08 11:23:53 --> Model Class Initialized
DEBUG - 2013-01-08 11:23:53 --> Model Class Initialized
DEBUG - 2013-01-08 11:23:53 --> Database Driver Class Initialized
DEBUG - 2013-01-08 11:23:53 --> Final output sent to browser
DEBUG - 2013-01-08 11:23:53 --> Total execution time: 0.1942
DEBUG - 2013-01-08 11:24:20 --> Config Class Initialized
DEBUG - 2013-01-08 11:24:20 --> Hooks Class Initialized
DEBUG - 2013-01-08 11:24:20 --> Utf8 Class Initialized
DEBUG - 2013-01-08 11:24:20 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 11:24:20 --> URI Class Initialized
DEBUG - 2013-01-08 11:24:20 --> Router Class Initialized
DEBUG - 2013-01-08 11:24:20 --> Output Class Initialized
DEBUG - 2013-01-08 11:24:20 --> Security Class Initialized
DEBUG - 2013-01-08 11:24:20 --> Input Class Initialized
DEBUG - 2013-01-08 11:24:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 11:24:20 --> Language Class Initialized
DEBUG - 2013-01-08 11:24:20 --> Loader Class Initialized
DEBUG - 2013-01-08 11:24:20 --> Helper loaded: url_helper
DEBUG - 2013-01-08 11:24:20 --> Controller Class Initialized
DEBUG - 2013-01-08 11:24:20 --> Model Class Initialized
DEBUG - 2013-01-08 11:24:20 --> Model Class Initialized
DEBUG - 2013-01-08 11:24:20 --> Database Driver Class Initialized
DEBUG - 2013-01-08 11:24:20 --> Final output sent to browser
DEBUG - 2013-01-08 11:24:20 --> Total execution time: 0.1621
DEBUG - 2013-01-08 11:24:31 --> Config Class Initialized
DEBUG - 2013-01-08 11:24:31 --> Hooks Class Initialized
DEBUG - 2013-01-08 11:24:31 --> Utf8 Class Initialized
DEBUG - 2013-01-08 11:24:31 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 11:24:31 --> URI Class Initialized
DEBUG - 2013-01-08 11:24:31 --> Router Class Initialized
DEBUG - 2013-01-08 11:24:31 --> Output Class Initialized
DEBUG - 2013-01-08 11:24:31 --> Security Class Initialized
DEBUG - 2013-01-08 11:24:31 --> Input Class Initialized
DEBUG - 2013-01-08 11:24:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 11:24:31 --> Language Class Initialized
DEBUG - 2013-01-08 11:24:31 --> Loader Class Initialized
DEBUG - 2013-01-08 11:24:31 --> Helper loaded: url_helper
DEBUG - 2013-01-08 11:24:31 --> Controller Class Initialized
DEBUG - 2013-01-08 11:24:31 --> Model Class Initialized
DEBUG - 2013-01-08 11:24:31 --> Model Class Initialized
DEBUG - 2013-01-08 11:24:31 --> Database Driver Class Initialized
DEBUG - 2013-01-08 11:24:31 --> Final output sent to browser
DEBUG - 2013-01-08 11:24:31 --> Total execution time: 0.1596
DEBUG - 2013-01-08 11:24:36 --> Config Class Initialized
DEBUG - 2013-01-08 11:24:36 --> Hooks Class Initialized
DEBUG - 2013-01-08 11:24:36 --> Utf8 Class Initialized
DEBUG - 2013-01-08 11:24:36 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 11:24:36 --> URI Class Initialized
DEBUG - 2013-01-08 11:24:36 --> Router Class Initialized
DEBUG - 2013-01-08 11:24:36 --> Output Class Initialized
DEBUG - 2013-01-08 11:24:36 --> Security Class Initialized
DEBUG - 2013-01-08 11:24:36 --> Input Class Initialized
DEBUG - 2013-01-08 11:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 11:24:36 --> Language Class Initialized
DEBUG - 2013-01-08 11:24:36 --> Loader Class Initialized
DEBUG - 2013-01-08 11:24:36 --> Helper loaded: url_helper
DEBUG - 2013-01-08 11:24:36 --> Controller Class Initialized
DEBUG - 2013-01-08 11:24:36 --> Model Class Initialized
DEBUG - 2013-01-08 11:24:36 --> Model Class Initialized
DEBUG - 2013-01-08 11:24:36 --> Database Driver Class Initialized
DEBUG - 2013-01-08 11:24:36 --> Final output sent to browser
DEBUG - 2013-01-08 11:24:36 --> Total execution time: 0.1559
DEBUG - 2013-01-08 17:01:46 --> Config Class Initialized
DEBUG - 2013-01-08 17:01:46 --> Hooks Class Initialized
DEBUG - 2013-01-08 17:01:46 --> Utf8 Class Initialized
DEBUG - 2013-01-08 17:01:46 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 17:01:47 --> URI Class Initialized
DEBUG - 2013-01-08 17:01:47 --> Router Class Initialized
DEBUG - 2013-01-08 17:01:47 --> No URI present. Default controller set.
DEBUG - 2013-01-08 17:01:47 --> Output Class Initialized
DEBUG - 2013-01-08 17:01:47 --> Security Class Initialized
DEBUG - 2013-01-08 17:01:47 --> Input Class Initialized
DEBUG - 2013-01-08 17:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 17:01:47 --> Language Class Initialized
DEBUG - 2013-01-08 17:01:47 --> Loader Class Initialized
DEBUG - 2013-01-08 17:01:47 --> Helper loaded: url_helper
DEBUG - 2013-01-08 17:01:47 --> Controller Class Initialized
DEBUG - 2013-01-08 17:01:47 --> Model Class Initialized
DEBUG - 2013-01-08 17:01:47 --> Model Class Initialized
DEBUG - 2013-01-08 17:01:47 --> Database Driver Class Initialized
DEBUG - 2013-01-08 17:01:47 --> File loaded: application/views/home.php
DEBUG - 2013-01-08 17:01:47 --> Final output sent to browser
DEBUG - 2013-01-08 17:01:47 --> Total execution time: 0.4937
DEBUG - 2013-01-08 17:04:44 --> Config Class Initialized
DEBUG - 2013-01-08 17:04:44 --> Hooks Class Initialized
DEBUG - 2013-01-08 17:04:44 --> Utf8 Class Initialized
DEBUG - 2013-01-08 17:04:44 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 17:04:44 --> URI Class Initialized
DEBUG - 2013-01-08 17:04:44 --> Router Class Initialized
DEBUG - 2013-01-08 17:04:44 --> No URI present. Default controller set.
DEBUG - 2013-01-08 17:04:44 --> Output Class Initialized
DEBUG - 2013-01-08 17:04:44 --> Security Class Initialized
DEBUG - 2013-01-08 17:04:44 --> Input Class Initialized
DEBUG - 2013-01-08 17:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 17:04:44 --> Language Class Initialized
DEBUG - 2013-01-08 17:04:44 --> Loader Class Initialized
DEBUG - 2013-01-08 17:04:45 --> Helper loaded: url_helper
DEBUG - 2013-01-08 17:04:45 --> Controller Class Initialized
DEBUG - 2013-01-08 17:04:45 --> Model Class Initialized
DEBUG - 2013-01-08 17:04:45 --> Model Class Initialized
DEBUG - 2013-01-08 17:04:45 --> Database Driver Class Initialized
DEBUG - 2013-01-08 17:04:45 --> File loaded: application/views/home.php
DEBUG - 2013-01-08 17:04:45 --> Final output sent to browser
DEBUG - 2013-01-08 17:04:45 --> Total execution time: 0.2046
DEBUG - 2013-01-08 17:05:10 --> Config Class Initialized
DEBUG - 2013-01-08 17:05:10 --> Hooks Class Initialized
DEBUG - 2013-01-08 17:05:10 --> Utf8 Class Initialized
DEBUG - 2013-01-08 17:05:10 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 17:05:10 --> URI Class Initialized
DEBUG - 2013-01-08 17:05:10 --> Router Class Initialized
DEBUG - 2013-01-08 17:05:10 --> Output Class Initialized
DEBUG - 2013-01-08 17:05:10 --> Security Class Initialized
DEBUG - 2013-01-08 17:05:10 --> Input Class Initialized
DEBUG - 2013-01-08 17:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 17:05:10 --> Language Class Initialized
DEBUG - 2013-01-08 17:05:10 --> Loader Class Initialized
DEBUG - 2013-01-08 17:05:10 --> Helper loaded: url_helper
DEBUG - 2013-01-08 17:05:10 --> Controller Class Initialized
DEBUG - 2013-01-08 17:05:10 --> Model Class Initialized
DEBUG - 2013-01-08 17:05:10 --> Model Class Initialized
DEBUG - 2013-01-08 17:05:10 --> Database Driver Class Initialized
ERROR - 2013-01-08 17:05:10 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mobiba_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-01-08 17:05:10 --> File loaded: application/views/register.php
DEBUG - 2013-01-08 17:05:10 --> Final output sent to browser
DEBUG - 2013-01-08 17:05:10 --> Total execution time: 0.2483
DEBUG - 2013-01-08 17:05:11 --> Config Class Initialized
DEBUG - 2013-01-08 17:05:11 --> Hooks Class Initialized
DEBUG - 2013-01-08 17:05:11 --> Utf8 Class Initialized
DEBUG - 2013-01-08 17:05:11 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 17:05:11 --> URI Class Initialized
DEBUG - 2013-01-08 17:05:11 --> Router Class Initialized
ERROR - 2013-01-08 17:05:11 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-08 17:05:58 --> Config Class Initialized
DEBUG - 2013-01-08 17:05:58 --> Hooks Class Initialized
DEBUG - 2013-01-08 17:05:58 --> Utf8 Class Initialized
DEBUG - 2013-01-08 17:05:58 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 17:05:58 --> URI Class Initialized
DEBUG - 2013-01-08 17:05:58 --> Router Class Initialized
DEBUG - 2013-01-08 17:05:58 --> Output Class Initialized
DEBUG - 2013-01-08 17:05:58 --> Security Class Initialized
DEBUG - 2013-01-08 17:05:58 --> Input Class Initialized
DEBUG - 2013-01-08 17:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 17:05:58 --> Language Class Initialized
DEBUG - 2013-01-08 17:05:58 --> Loader Class Initialized
DEBUG - 2013-01-08 17:05:58 --> Helper loaded: url_helper
DEBUG - 2013-01-08 17:05:58 --> Controller Class Initialized
DEBUG - 2013-01-08 17:05:58 --> Model Class Initialized
DEBUG - 2013-01-08 17:05:58 --> Model Class Initialized
DEBUG - 2013-01-08 17:05:58 --> Database Driver Class Initialized
DEBUG - 2013-01-08 17:05:58 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-08 17:05:58 --> Final output sent to browser
DEBUG - 2013-01-08 17:05:58 --> Total execution time: 0.2264
DEBUG - 2013-01-08 17:05:58 --> Config Class Initialized
DEBUG - 2013-01-08 17:05:58 --> Hooks Class Initialized
DEBUG - 2013-01-08 17:05:58 --> Utf8 Class Initialized
DEBUG - 2013-01-08 17:05:58 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 17:05:58 --> URI Class Initialized
DEBUG - 2013-01-08 17:05:58 --> Router Class Initialized
ERROR - 2013-01-08 17:05:58 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-08 17:33:22 --> Config Class Initialized
DEBUG - 2013-01-08 17:33:22 --> Hooks Class Initialized
DEBUG - 2013-01-08 17:33:22 --> Utf8 Class Initialized
DEBUG - 2013-01-08 17:33:22 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 17:33:22 --> URI Class Initialized
DEBUG - 2013-01-08 17:33:22 --> Router Class Initialized
DEBUG - 2013-01-08 17:33:22 --> Output Class Initialized
DEBUG - 2013-01-08 17:33:22 --> Security Class Initialized
DEBUG - 2013-01-08 17:33:22 --> Input Class Initialized
DEBUG - 2013-01-08 17:33:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 17:33:22 --> Language Class Initialized
DEBUG - 2013-01-08 17:33:22 --> Loader Class Initialized
DEBUG - 2013-01-08 17:33:22 --> Helper loaded: url_helper
DEBUG - 2013-01-08 17:33:22 --> Controller Class Initialized
DEBUG - 2013-01-08 17:33:22 --> Model Class Initialized
DEBUG - 2013-01-08 17:33:22 --> Model Class Initialized
DEBUG - 2013-01-08 17:33:22 --> Database Driver Class Initialized
DEBUG - 2013-01-08 17:33:22 --> Final output sent to browser
DEBUG - 2013-01-08 17:33:22 --> Total execution time: 0.2318
DEBUG - 2013-01-08 17:33:29 --> Config Class Initialized
DEBUG - 2013-01-08 17:33:29 --> Hooks Class Initialized
DEBUG - 2013-01-08 17:33:29 --> Utf8 Class Initialized
DEBUG - 2013-01-08 17:33:29 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 17:33:29 --> URI Class Initialized
DEBUG - 2013-01-08 17:33:29 --> Router Class Initialized
DEBUG - 2013-01-08 17:33:29 --> Output Class Initialized
DEBUG - 2013-01-08 17:33:29 --> Security Class Initialized
DEBUG - 2013-01-08 17:33:29 --> Input Class Initialized
DEBUG - 2013-01-08 17:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 17:33:29 --> Language Class Initialized
DEBUG - 2013-01-08 17:33:29 --> Loader Class Initialized
DEBUG - 2013-01-08 17:33:29 --> Helper loaded: url_helper
DEBUG - 2013-01-08 17:33:29 --> Controller Class Initialized
DEBUG - 2013-01-08 17:33:29 --> Model Class Initialized
DEBUG - 2013-01-08 17:33:29 --> Model Class Initialized
DEBUG - 2013-01-08 17:33:29 --> Database Driver Class Initialized
DEBUG - 2013-01-08 17:33:29 --> Final output sent to browser
DEBUG - 2013-01-08 17:33:29 --> Total execution time: 0.2168
DEBUG - 2013-01-08 18:55:59 --> Config Class Initialized
DEBUG - 2013-01-08 18:55:59 --> Hooks Class Initialized
DEBUG - 2013-01-08 18:55:59 --> Utf8 Class Initialized
DEBUG - 2013-01-08 18:55:59 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 18:55:59 --> URI Class Initialized
DEBUG - 2013-01-08 18:55:59 --> Router Class Initialized
DEBUG - 2013-01-08 18:55:59 --> No URI present. Default controller set.
DEBUG - 2013-01-08 18:55:59 --> Output Class Initialized
DEBUG - 2013-01-08 18:55:59 --> Security Class Initialized
DEBUG - 2013-01-08 18:55:59 --> Input Class Initialized
DEBUG - 2013-01-08 18:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 18:55:59 --> Language Class Initialized
DEBUG - 2013-01-08 18:55:59 --> Loader Class Initialized
DEBUG - 2013-01-08 18:55:59 --> Helper loaded: url_helper
DEBUG - 2013-01-08 18:55:59 --> Controller Class Initialized
DEBUG - 2013-01-08 18:55:59 --> Model Class Initialized
DEBUG - 2013-01-08 18:55:59 --> Model Class Initialized
DEBUG - 2013-01-08 18:55:59 --> Database Driver Class Initialized
DEBUG - 2013-01-08 18:55:59 --> File loaded: application/views/home.php
DEBUG - 2013-01-08 18:55:59 --> Final output sent to browser
DEBUG - 2013-01-08 18:55:59 --> Total execution time: 0.1757
DEBUG - 2013-01-08 18:56:01 --> Config Class Initialized
DEBUG - 2013-01-08 18:56:01 --> Hooks Class Initialized
DEBUG - 2013-01-08 18:56:01 --> Utf8 Class Initialized
DEBUG - 2013-01-08 18:56:01 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 18:56:01 --> URI Class Initialized
DEBUG - 2013-01-08 18:56:01 --> Router Class Initialized
DEBUG - 2013-01-08 18:56:01 --> Output Class Initialized
DEBUG - 2013-01-08 18:56:01 --> Security Class Initialized
DEBUG - 2013-01-08 18:56:01 --> Input Class Initialized
DEBUG - 2013-01-08 18:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 18:56:01 --> Language Class Initialized
DEBUG - 2013-01-08 18:56:01 --> Loader Class Initialized
DEBUG - 2013-01-08 18:56:01 --> Helper loaded: url_helper
DEBUG - 2013-01-08 18:56:01 --> Controller Class Initialized
DEBUG - 2013-01-08 18:56:01 --> Model Class Initialized
DEBUG - 2013-01-08 18:56:01 --> Model Class Initialized
DEBUG - 2013-01-08 18:56:01 --> Database Driver Class Initialized
DEBUG - 2013-01-08 18:56:01 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-08 18:56:01 --> Final output sent to browser
DEBUG - 2013-01-08 18:56:01 --> Total execution time: 0.1754
DEBUG - 2013-01-08 18:56:01 --> Config Class Initialized
DEBUG - 2013-01-08 18:56:01 --> Hooks Class Initialized
DEBUG - 2013-01-08 18:56:01 --> Utf8 Class Initialized
DEBUG - 2013-01-08 18:56:01 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 18:56:01 --> URI Class Initialized
DEBUG - 2013-01-08 18:56:01 --> Router Class Initialized
ERROR - 2013-01-08 18:56:01 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-08 18:59:17 --> Config Class Initialized
DEBUG - 2013-01-08 18:59:17 --> Hooks Class Initialized
DEBUG - 2013-01-08 18:59:17 --> Utf8 Class Initialized
DEBUG - 2013-01-08 18:59:17 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 18:59:17 --> URI Class Initialized
DEBUG - 2013-01-08 18:59:17 --> Router Class Initialized
DEBUG - 2013-01-08 18:59:17 --> Output Class Initialized
DEBUG - 2013-01-08 18:59:17 --> Security Class Initialized
DEBUG - 2013-01-08 18:59:17 --> Input Class Initialized
DEBUG - 2013-01-08 18:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 18:59:17 --> Language Class Initialized
DEBUG - 2013-01-08 18:59:17 --> Loader Class Initialized
DEBUG - 2013-01-08 18:59:17 --> Helper loaded: url_helper
DEBUG - 2013-01-08 18:59:17 --> Controller Class Initialized
DEBUG - 2013-01-08 18:59:17 --> Model Class Initialized
DEBUG - 2013-01-08 18:59:17 --> Model Class Initialized
DEBUG - 2013-01-08 18:59:17 --> Database Driver Class Initialized
DEBUG - 2013-01-08 18:59:17 --> Final output sent to browser
DEBUG - 2013-01-08 18:59:17 --> Total execution time: 0.1695
DEBUG - 2013-01-08 19:00:51 --> Config Class Initialized
DEBUG - 2013-01-08 19:00:51 --> Hooks Class Initialized
DEBUG - 2013-01-08 19:00:51 --> Utf8 Class Initialized
DEBUG - 2013-01-08 19:00:51 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 19:00:51 --> URI Class Initialized
DEBUG - 2013-01-08 19:00:51 --> Router Class Initialized
DEBUG - 2013-01-08 19:00:51 --> Output Class Initialized
DEBUG - 2013-01-08 19:00:51 --> Security Class Initialized
DEBUG - 2013-01-08 19:00:51 --> Input Class Initialized
DEBUG - 2013-01-08 19:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 19:00:51 --> Language Class Initialized
DEBUG - 2013-01-08 19:00:51 --> Loader Class Initialized
DEBUG - 2013-01-08 19:00:51 --> Helper loaded: url_helper
DEBUG - 2013-01-08 19:00:51 --> Controller Class Initialized
DEBUG - 2013-01-08 19:00:51 --> Model Class Initialized
DEBUG - 2013-01-08 19:00:51 --> Model Class Initialized
DEBUG - 2013-01-08 19:00:51 --> Database Driver Class Initialized
DEBUG - 2013-01-08 19:00:51 --> Final output sent to browser
DEBUG - 2013-01-08 19:00:51 --> Total execution time: 0.2169
DEBUG - 2013-01-08 19:02:20 --> Config Class Initialized
DEBUG - 2013-01-08 19:02:20 --> Hooks Class Initialized
DEBUG - 2013-01-08 19:02:20 --> Utf8 Class Initialized
DEBUG - 2013-01-08 19:02:20 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 19:02:20 --> URI Class Initialized
DEBUG - 2013-01-08 19:02:20 --> Router Class Initialized
DEBUG - 2013-01-08 19:02:20 --> Output Class Initialized
DEBUG - 2013-01-08 19:02:20 --> Security Class Initialized
DEBUG - 2013-01-08 19:02:20 --> Input Class Initialized
DEBUG - 2013-01-08 19:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 19:02:20 --> Language Class Initialized
DEBUG - 2013-01-08 19:02:20 --> Loader Class Initialized
DEBUG - 2013-01-08 19:02:20 --> Helper loaded: url_helper
DEBUG - 2013-01-08 19:02:20 --> Controller Class Initialized
DEBUG - 2013-01-08 19:02:20 --> Model Class Initialized
DEBUG - 2013-01-08 19:02:20 --> Model Class Initialized
DEBUG - 2013-01-08 19:02:20 --> Database Driver Class Initialized
DEBUG - 2013-01-08 19:02:20 --> Final output sent to browser
DEBUG - 2013-01-08 19:02:20 --> Total execution time: 0.1663
DEBUG - 2013-01-08 19:03:18 --> Config Class Initialized
DEBUG - 2013-01-08 19:03:18 --> Hooks Class Initialized
DEBUG - 2013-01-08 19:03:18 --> Utf8 Class Initialized
DEBUG - 2013-01-08 19:03:18 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 19:03:18 --> URI Class Initialized
DEBUG - 2013-01-08 19:03:18 --> Router Class Initialized
DEBUG - 2013-01-08 19:03:18 --> Output Class Initialized
DEBUG - 2013-01-08 19:03:18 --> Security Class Initialized
DEBUG - 2013-01-08 19:03:18 --> Input Class Initialized
DEBUG - 2013-01-08 19:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 19:03:18 --> Language Class Initialized
DEBUG - 2013-01-08 19:03:18 --> Loader Class Initialized
DEBUG - 2013-01-08 19:03:18 --> Helper loaded: url_helper
DEBUG - 2013-01-08 19:03:18 --> Controller Class Initialized
DEBUG - 2013-01-08 19:03:18 --> Model Class Initialized
DEBUG - 2013-01-08 19:03:18 --> Model Class Initialized
DEBUG - 2013-01-08 19:03:18 --> Database Driver Class Initialized
DEBUG - 2013-01-08 19:03:18 --> Final output sent to browser
DEBUG - 2013-01-08 19:03:18 --> Total execution time: 0.1745
DEBUG - 2013-01-08 19:06:19 --> Config Class Initialized
DEBUG - 2013-01-08 19:06:19 --> Hooks Class Initialized
DEBUG - 2013-01-08 19:06:19 --> Utf8 Class Initialized
DEBUG - 2013-01-08 19:06:19 --> UTF-8 Support Enabled
DEBUG - 2013-01-08 19:06:19 --> URI Class Initialized
DEBUG - 2013-01-08 19:06:19 --> Router Class Initialized
DEBUG - 2013-01-08 19:06:19 --> Output Class Initialized
DEBUG - 2013-01-08 19:06:19 --> Security Class Initialized
DEBUG - 2013-01-08 19:06:19 --> Input Class Initialized
DEBUG - 2013-01-08 19:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-08 19:06:19 --> Language Class Initialized
DEBUG - 2013-01-08 19:06:19 --> Loader Class Initialized
DEBUG - 2013-01-08 19:06:19 --> Helper loaded: url_helper
DEBUG - 2013-01-08 19:06:19 --> Controller Class Initialized
DEBUG - 2013-01-08 19:06:19 --> Model Class Initialized
DEBUG - 2013-01-08 19:06:19 --> Model Class Initialized
DEBUG - 2013-01-08 19:06:19 --> Database Driver Class Initialized
DEBUG - 2013-01-08 19:06:20 --> Final output sent to browser
DEBUG - 2013-01-08 19:06:20 --> Total execution time: 0.6408

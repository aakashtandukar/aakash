<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-01-09 04:02:49 --> Config Class Initialized
DEBUG - 2013-01-09 04:02:49 --> Hooks Class Initialized
DEBUG - 2013-01-09 04:02:49 --> Utf8 Class Initialized
DEBUG - 2013-01-09 04:02:49 --> UTF-8 Support Enabled
DEBUG - 2013-01-09 04:02:49 --> URI Class Initialized
DEBUG - 2013-01-09 04:02:49 --> Router Class Initialized
DEBUG - 2013-01-09 04:02:49 --> Output Class Initialized
DEBUG - 2013-01-09 04:02:49 --> Security Class Initialized
DEBUG - 2013-01-09 04:02:49 --> Input Class Initialized
DEBUG - 2013-01-09 04:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-09 04:02:49 --> Language Class Initialized
DEBUG - 2013-01-09 04:02:49 --> Loader Class Initialized
DEBUG - 2013-01-09 04:02:49 --> Helper loaded: url_helper
DEBUG - 2013-01-09 04:02:49 --> Controller Class Initialized
DEBUG - 2013-01-09 04:02:49 --> Model Class Initialized
DEBUG - 2013-01-09 04:02:49 --> Model Class Initialized
DEBUG - 2013-01-09 04:02:49 --> Database Driver Class Initialized
DEBUG - 2013-01-09 04:02:49 --> Final output sent to browser
DEBUG - 2013-01-09 04:02:49 --> Total execution time: 0.5090
DEBUG - 2013-01-09 04:03:42 --> Config Class Initialized
DEBUG - 2013-01-09 04:03:42 --> Hooks Class Initialized
DEBUG - 2013-01-09 04:03:42 --> Utf8 Class Initialized
DEBUG - 2013-01-09 04:03:42 --> UTF-8 Support Enabled
DEBUG - 2013-01-09 04:03:42 --> URI Class Initialized
DEBUG - 2013-01-09 04:03:42 --> Router Class Initialized
DEBUG - 2013-01-09 04:03:42 --> Output Class Initialized
DEBUG - 2013-01-09 04:03:42 --> Security Class Initialized
DEBUG - 2013-01-09 04:03:42 --> Input Class Initialized
DEBUG - 2013-01-09 04:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-09 04:03:42 --> Language Class Initialized
DEBUG - 2013-01-09 04:03:42 --> Loader Class Initialized
DEBUG - 2013-01-09 04:03:42 --> Helper loaded: url_helper
DEBUG - 2013-01-09 04:03:42 --> Controller Class Initialized
DEBUG - 2013-01-09 04:03:42 --> Model Class Initialized
DEBUG - 2013-01-09 04:03:42 --> Model Class Initialized
DEBUG - 2013-01-09 04:03:42 --> Database Driver Class Initialized
DEBUG - 2013-01-09 04:03:42 --> Final output sent to browser
DEBUG - 2013-01-09 04:03:42 --> Total execution time: 0.2598
DEBUG - 2013-01-09 04:04:09 --> Config Class Initialized
DEBUG - 2013-01-09 04:04:09 --> Hooks Class Initialized
DEBUG - 2013-01-09 04:04:09 --> Utf8 Class Initialized
DEBUG - 2013-01-09 04:04:09 --> UTF-8 Support Enabled
DEBUG - 2013-01-09 04:04:09 --> URI Class Initialized
DEBUG - 2013-01-09 04:04:09 --> Router Class Initialized
DEBUG - 2013-01-09 04:04:09 --> Output Class Initialized
DEBUG - 2013-01-09 04:04:09 --> Security Class Initialized
DEBUG - 2013-01-09 04:04:09 --> Input Class Initialized
DEBUG - 2013-01-09 04:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-09 04:04:09 --> Language Class Initialized
DEBUG - 2013-01-09 04:04:09 --> Loader Class Initialized
DEBUG - 2013-01-09 04:04:09 --> Helper loaded: url_helper
DEBUG - 2013-01-09 04:04:09 --> Controller Class Initialized
DEBUG - 2013-01-09 04:04:09 --> Model Class Initialized
DEBUG - 2013-01-09 04:04:09 --> Model Class Initialized
DEBUG - 2013-01-09 04:04:09 --> Database Driver Class Initialized
DEBUG - 2013-01-09 04:04:09 --> Final output sent to browser
DEBUG - 2013-01-09 04:04:09 --> Total execution time: 0.1378
DEBUG - 2013-01-09 04:04:16 --> Config Class Initialized
DEBUG - 2013-01-09 04:04:16 --> Hooks Class Initialized
DEBUG - 2013-01-09 04:04:16 --> Utf8 Class Initialized
DEBUG - 2013-01-09 04:04:16 --> UTF-8 Support Enabled
DEBUG - 2013-01-09 04:04:16 --> URI Class Initialized
DEBUG - 2013-01-09 04:04:16 --> Router Class Initialized
DEBUG - 2013-01-09 04:04:16 --> Output Class Initialized
DEBUG - 2013-01-09 04:04:16 --> Security Class Initialized
DEBUG - 2013-01-09 04:04:16 --> Input Class Initialized
DEBUG - 2013-01-09 04:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-09 04:04:16 --> Language Class Initialized
DEBUG - 2013-01-09 04:04:16 --> Loader Class Initialized
DEBUG - 2013-01-09 04:04:16 --> Helper loaded: url_helper
DEBUG - 2013-01-09 04:04:16 --> Controller Class Initialized
DEBUG - 2013-01-09 04:04:16 --> Model Class Initialized
DEBUG - 2013-01-09 04:04:16 --> Model Class Initialized
DEBUG - 2013-01-09 04:04:16 --> Database Driver Class Initialized
DEBUG - 2013-01-09 04:04:16 --> Final output sent to browser
DEBUG - 2013-01-09 04:04:16 --> Total execution time: 0.1503
DEBUG - 2013-01-09 04:04:57 --> Config Class Initialized
DEBUG - 2013-01-09 04:04:57 --> Hooks Class Initialized
DEBUG - 2013-01-09 04:04:57 --> Utf8 Class Initialized
DEBUG - 2013-01-09 04:04:57 --> UTF-8 Support Enabled
DEBUG - 2013-01-09 04:04:57 --> URI Class Initialized
DEBUG - 2013-01-09 04:04:57 --> Router Class Initialized
DEBUG - 2013-01-09 04:04:57 --> No URI present. Default controller set.
DEBUG - 2013-01-09 04:04:57 --> Output Class Initialized
DEBUG - 2013-01-09 04:04:57 --> Security Class Initialized
DEBUG - 2013-01-09 04:04:57 --> Input Class Initialized
DEBUG - 2013-01-09 04:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-09 04:04:57 --> Language Class Initialized
DEBUG - 2013-01-09 04:04:57 --> Loader Class Initialized
DEBUG - 2013-01-09 04:04:57 --> Helper loaded: url_helper
DEBUG - 2013-01-09 04:04:57 --> Controller Class Initialized
DEBUG - 2013-01-09 04:04:57 --> Model Class Initialized
DEBUG - 2013-01-09 04:04:57 --> Model Class Initialized
DEBUG - 2013-01-09 04:04:57 --> Database Driver Class Initialized
DEBUG - 2013-01-09 04:04:57 --> File loaded: application/views/home.php
DEBUG - 2013-01-09 04:04:57 --> Final output sent to browser
DEBUG - 2013-01-09 04:04:57 --> Total execution time: 0.2140
DEBUG - 2013-01-09 04:05:00 --> Config Class Initialized
DEBUG - 2013-01-09 04:05:00 --> Hooks Class Initialized
DEBUG - 2013-01-09 04:05:00 --> Utf8 Class Initialized
DEBUG - 2013-01-09 04:05:00 --> UTF-8 Support Enabled
DEBUG - 2013-01-09 04:05:00 --> URI Class Initialized
DEBUG - 2013-01-09 04:05:00 --> Router Class Initialized
DEBUG - 2013-01-09 04:05:00 --> Output Class Initialized
DEBUG - 2013-01-09 04:05:00 --> Security Class Initialized
DEBUG - 2013-01-09 04:05:00 --> Input Class Initialized
DEBUG - 2013-01-09 04:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-09 04:05:00 --> Language Class Initialized
DEBUG - 2013-01-09 04:05:00 --> Loader Class Initialized
DEBUG - 2013-01-09 04:05:00 --> Helper loaded: url_helper
DEBUG - 2013-01-09 04:05:00 --> Controller Class Initialized
DEBUG - 2013-01-09 04:05:00 --> Model Class Initialized
DEBUG - 2013-01-09 04:05:00 --> Model Class Initialized
DEBUG - 2013-01-09 04:05:00 --> Database Driver Class Initialized
DEBUG - 2013-01-09 04:05:00 --> File loaded: application/views/register.php
DEBUG - 2013-01-09 04:05:00 --> Final output sent to browser
DEBUG - 2013-01-09 04:05:00 --> Total execution time: 0.2060
DEBUG - 2013-01-09 04:05:00 --> Config Class Initialized
DEBUG - 2013-01-09 04:05:00 --> Hooks Class Initialized
DEBUG - 2013-01-09 04:05:00 --> Utf8 Class Initialized
DEBUG - 2013-01-09 04:05:00 --> UTF-8 Support Enabled
DEBUG - 2013-01-09 04:05:00 --> URI Class Initialized
DEBUG - 2013-01-09 04:05:00 --> Router Class Initialized
ERROR - 2013-01-09 04:05:00 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-09 04:05:06 --> Config Class Initialized
DEBUG - 2013-01-09 04:05:06 --> Hooks Class Initialized
DEBUG - 2013-01-09 04:05:06 --> Utf8 Class Initialized
DEBUG - 2013-01-09 04:05:06 --> UTF-8 Support Enabled
DEBUG - 2013-01-09 04:05:06 --> URI Class Initialized
DEBUG - 2013-01-09 04:05:06 --> Router Class Initialized
DEBUG - 2013-01-09 04:05:06 --> Output Class Initialized
DEBUG - 2013-01-09 04:05:06 --> Security Class Initialized
DEBUG - 2013-01-09 04:05:06 --> Input Class Initialized
DEBUG - 2013-01-09 04:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-09 04:05:06 --> Language Class Initialized
DEBUG - 2013-01-09 04:05:06 --> Loader Class Initialized
DEBUG - 2013-01-09 04:05:06 --> Helper loaded: url_helper
DEBUG - 2013-01-09 04:05:06 --> Controller Class Initialized
DEBUG - 2013-01-09 04:05:06 --> Model Class Initialized
DEBUG - 2013-01-09 04:05:06 --> Model Class Initialized
DEBUG - 2013-01-09 04:05:06 --> Database Driver Class Initialized
DEBUG - 2013-01-09 04:05:06 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-09 04:05:06 --> Final output sent to browser
DEBUG - 2013-01-09 04:05:06 --> Total execution time: 0.1718
DEBUG - 2013-01-09 04:05:06 --> Config Class Initialized
DEBUG - 2013-01-09 04:05:06 --> Hooks Class Initialized
DEBUG - 2013-01-09 04:05:06 --> Utf8 Class Initialized
DEBUG - 2013-01-09 04:05:06 --> UTF-8 Support Enabled
DEBUG - 2013-01-09 04:05:06 --> URI Class Initialized
DEBUG - 2013-01-09 04:05:06 --> Router Class Initialized
ERROR - 2013-01-09 04:05:06 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-09 04:09:09 --> Config Class Initialized
DEBUG - 2013-01-09 04:09:09 --> Hooks Class Initialized
DEBUG - 2013-01-09 04:09:09 --> Utf8 Class Initialized
DEBUG - 2013-01-09 04:09:09 --> UTF-8 Support Enabled
DEBUG - 2013-01-09 04:09:09 --> URI Class Initialized
DEBUG - 2013-01-09 04:09:09 --> Router Class Initialized
DEBUG - 2013-01-09 04:09:09 --> Output Class Initialized
DEBUG - 2013-01-09 04:09:09 --> Security Class Initialized
DEBUG - 2013-01-09 04:09:09 --> Input Class Initialized
DEBUG - 2013-01-09 04:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-09 04:09:09 --> Language Class Initialized
DEBUG - 2013-01-09 04:09:09 --> Loader Class Initialized
DEBUG - 2013-01-09 04:09:09 --> Helper loaded: url_helper
DEBUG - 2013-01-09 04:09:09 --> Controller Class Initialized
DEBUG - 2013-01-09 04:09:09 --> Model Class Initialized
DEBUG - 2013-01-09 04:09:09 --> Model Class Initialized
DEBUG - 2013-01-09 04:09:09 --> Database Driver Class Initialized
DEBUG - 2013-01-09 04:09:09 --> Final output sent to browser
DEBUG - 2013-01-09 04:09:09 --> Total execution time: 0.1578

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-01-06 02:16:55 --> Config Class Initialized
DEBUG - 2013-01-06 02:16:55 --> Hooks Class Initialized
DEBUG - 2013-01-06 02:16:55 --> Utf8 Class Initialized
DEBUG - 2013-01-06 02:16:55 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 02:16:55 --> URI Class Initialized
DEBUG - 2013-01-06 02:16:55 --> Router Class Initialized
DEBUG - 2013-01-06 02:16:55 --> No URI present. Default controller set.
DEBUG - 2013-01-06 02:16:56 --> Output Class Initialized
DEBUG - 2013-01-06 02:16:56 --> Security Class Initialized
DEBUG - 2013-01-06 02:16:56 --> Input Class Initialized
DEBUG - 2013-01-06 02:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 02:16:56 --> Language Class Initialized
DEBUG - 2013-01-06 02:16:56 --> Loader Class Initialized
DEBUG - 2013-01-06 02:16:56 --> Helper loaded: url_helper
DEBUG - 2013-01-06 02:16:56 --> Controller Class Initialized
DEBUG - 2013-01-06 02:16:56 --> Model Class Initialized
DEBUG - 2013-01-06 02:16:56 --> Model Class Initialized
DEBUG - 2013-01-06 02:16:57 --> Database Driver Class Initialized
DEBUG - 2013-01-06 02:16:57 --> File loaded: application/views/home.php
DEBUG - 2013-01-06 02:16:57 --> Final output sent to browser
DEBUG - 2013-01-06 02:16:57 --> Total execution time: 1.9642
DEBUG - 2013-01-06 02:16:59 --> Config Class Initialized
DEBUG - 2013-01-06 02:16:59 --> Hooks Class Initialized
DEBUG - 2013-01-06 02:16:59 --> Utf8 Class Initialized
DEBUG - 2013-01-06 02:16:59 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 02:16:59 --> URI Class Initialized
DEBUG - 2013-01-06 02:16:59 --> Router Class Initialized
DEBUG - 2013-01-06 02:16:59 --> Output Class Initialized
DEBUG - 2013-01-06 02:16:59 --> Security Class Initialized
DEBUG - 2013-01-06 02:16:59 --> Input Class Initialized
DEBUG - 2013-01-06 02:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 02:16:59 --> Language Class Initialized
DEBUG - 2013-01-06 02:16:59 --> Loader Class Initialized
DEBUG - 2013-01-06 02:16:59 --> Helper loaded: url_helper
DEBUG - 2013-01-06 02:16:59 --> Controller Class Initialized
DEBUG - 2013-01-06 02:16:59 --> Model Class Initialized
DEBUG - 2013-01-06 02:16:59 --> Model Class Initialized
DEBUG - 2013-01-06 02:16:59 --> Database Driver Class Initialized
DEBUG - 2013-01-06 02:16:59 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-06 02:16:59 --> Final output sent to browser
DEBUG - 2013-01-06 02:16:59 --> Total execution time: 0.1779
DEBUG - 2013-01-06 02:16:59 --> Config Class Initialized
DEBUG - 2013-01-06 02:16:59 --> Hooks Class Initialized
DEBUG - 2013-01-06 02:16:59 --> Utf8 Class Initialized
DEBUG - 2013-01-06 02:16:59 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 02:16:59 --> URI Class Initialized
DEBUG - 2013-01-06 02:16:59 --> Router Class Initialized
ERROR - 2013-01-06 02:16:59 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-06 02:17:08 --> Config Class Initialized
DEBUG - 2013-01-06 02:17:08 --> Hooks Class Initialized
DEBUG - 2013-01-06 02:17:08 --> Utf8 Class Initialized
DEBUG - 2013-01-06 02:17:08 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 02:17:08 --> URI Class Initialized
DEBUG - 2013-01-06 02:17:08 --> Router Class Initialized
DEBUG - 2013-01-06 02:17:08 --> Output Class Initialized
DEBUG - 2013-01-06 02:17:08 --> Security Class Initialized
DEBUG - 2013-01-06 02:17:08 --> Input Class Initialized
DEBUG - 2013-01-06 02:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 02:17:08 --> Language Class Initialized
DEBUG - 2013-01-06 02:17:08 --> Loader Class Initialized
DEBUG - 2013-01-06 02:17:08 --> Helper loaded: url_helper
DEBUG - 2013-01-06 02:17:08 --> Controller Class Initialized
DEBUG - 2013-01-06 02:17:08 --> Model Class Initialized
DEBUG - 2013-01-06 02:17:08 --> Model Class Initialized
DEBUG - 2013-01-06 02:17:08 --> Database Driver Class Initialized
DEBUG - 2013-01-06 02:17:09 --> Final output sent to browser
DEBUG - 2013-01-06 02:17:09 --> Total execution time: 0.9644
DEBUG - 2013-01-06 02:44:37 --> Config Class Initialized
DEBUG - 2013-01-06 02:44:37 --> Hooks Class Initialized
DEBUG - 2013-01-06 02:44:37 --> Utf8 Class Initialized
DEBUG - 2013-01-06 02:44:37 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 02:44:37 --> URI Class Initialized
DEBUG - 2013-01-06 02:44:37 --> Router Class Initialized
DEBUG - 2013-01-06 02:44:37 --> No URI present. Default controller set.
DEBUG - 2013-01-06 02:44:37 --> Output Class Initialized
DEBUG - 2013-01-06 02:44:37 --> Security Class Initialized
DEBUG - 2013-01-06 02:44:37 --> Input Class Initialized
DEBUG - 2013-01-06 02:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 02:44:37 --> Language Class Initialized
DEBUG - 2013-01-06 02:44:37 --> Loader Class Initialized
DEBUG - 2013-01-06 02:44:37 --> Helper loaded: url_helper
DEBUG - 2013-01-06 02:44:37 --> Controller Class Initialized
DEBUG - 2013-01-06 02:44:37 --> Model Class Initialized
DEBUG - 2013-01-06 02:44:37 --> Model Class Initialized
DEBUG - 2013-01-06 02:44:37 --> Database Driver Class Initialized
DEBUG - 2013-01-06 02:44:37 --> File loaded: application/views/home.php
DEBUG - 2013-01-06 02:44:37 --> Final output sent to browser
DEBUG - 2013-01-06 02:44:37 --> Total execution time: 0.1532
DEBUG - 2013-01-06 02:44:40 --> Config Class Initialized
DEBUG - 2013-01-06 02:44:40 --> Hooks Class Initialized
DEBUG - 2013-01-06 02:44:40 --> Utf8 Class Initialized
DEBUG - 2013-01-06 02:44:40 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 02:44:40 --> URI Class Initialized
DEBUG - 2013-01-06 02:44:40 --> Router Class Initialized
DEBUG - 2013-01-06 02:44:40 --> Output Class Initialized
DEBUG - 2013-01-06 02:44:40 --> Security Class Initialized
DEBUG - 2013-01-06 02:44:40 --> Input Class Initialized
DEBUG - 2013-01-06 02:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 02:44:40 --> Language Class Initialized
DEBUG - 2013-01-06 02:44:40 --> Loader Class Initialized
DEBUG - 2013-01-06 02:44:40 --> Helper loaded: url_helper
DEBUG - 2013-01-06 02:44:40 --> Controller Class Initialized
DEBUG - 2013-01-06 02:44:40 --> Model Class Initialized
DEBUG - 2013-01-06 02:44:40 --> Model Class Initialized
DEBUG - 2013-01-06 02:44:40 --> Database Driver Class Initialized
DEBUG - 2013-01-06 02:44:40 --> File loaded: application/views/register.php
DEBUG - 2013-01-06 02:44:40 --> Final output sent to browser
DEBUG - 2013-01-06 02:44:40 --> Total execution time: 0.2241
DEBUG - 2013-01-06 02:44:40 --> Config Class Initialized
DEBUG - 2013-01-06 02:44:40 --> Hooks Class Initialized
DEBUG - 2013-01-06 02:44:40 --> Utf8 Class Initialized
DEBUG - 2013-01-06 02:44:40 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 02:44:40 --> URI Class Initialized
DEBUG - 2013-01-06 02:44:40 --> Router Class Initialized
ERROR - 2013-01-06 02:44:40 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-06 02:44:42 --> Config Class Initialized
DEBUG - 2013-01-06 02:44:42 --> Hooks Class Initialized
DEBUG - 2013-01-06 02:44:42 --> Utf8 Class Initialized
DEBUG - 2013-01-06 02:44:42 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 02:44:42 --> URI Class Initialized
DEBUG - 2013-01-06 02:44:42 --> Router Class Initialized
DEBUG - 2013-01-06 02:44:42 --> Output Class Initialized
DEBUG - 2013-01-06 02:44:42 --> Security Class Initialized
DEBUG - 2013-01-06 02:44:42 --> Input Class Initialized
DEBUG - 2013-01-06 02:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 02:44:42 --> Language Class Initialized
DEBUG - 2013-01-06 02:44:42 --> Loader Class Initialized
DEBUG - 2013-01-06 02:44:42 --> Helper loaded: url_helper
DEBUG - 2013-01-06 02:44:42 --> Controller Class Initialized
DEBUG - 2013-01-06 02:44:42 --> Model Class Initialized
DEBUG - 2013-01-06 02:44:42 --> Model Class Initialized
DEBUG - 2013-01-06 02:44:42 --> Database Driver Class Initialized
DEBUG - 2013-01-06 02:44:42 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-06 02:44:42 --> Final output sent to browser
DEBUG - 2013-01-06 02:44:42 --> Total execution time: 0.1588
DEBUG - 2013-01-06 02:44:42 --> Config Class Initialized
DEBUG - 2013-01-06 02:44:42 --> Hooks Class Initialized
DEBUG - 2013-01-06 02:44:42 --> Utf8 Class Initialized
DEBUG - 2013-01-06 02:44:42 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 02:44:42 --> URI Class Initialized
DEBUG - 2013-01-06 02:44:42 --> Router Class Initialized
ERROR - 2013-01-06 02:44:42 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-06 13:45:19 --> Config Class Initialized
DEBUG - 2013-01-06 13:45:19 --> Hooks Class Initialized
DEBUG - 2013-01-06 13:45:19 --> Utf8 Class Initialized
DEBUG - 2013-01-06 13:45:19 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 13:45:19 --> URI Class Initialized
DEBUG - 2013-01-06 13:45:19 --> Router Class Initialized
DEBUG - 2013-01-06 13:45:20 --> No URI present. Default controller set.
DEBUG - 2013-01-06 13:45:20 --> Output Class Initialized
DEBUG - 2013-01-06 13:45:20 --> Security Class Initialized
DEBUG - 2013-01-06 13:45:20 --> Input Class Initialized
DEBUG - 2013-01-06 13:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 13:45:20 --> Language Class Initialized
DEBUG - 2013-01-06 13:45:20 --> Loader Class Initialized
DEBUG - 2013-01-06 13:45:20 --> Helper loaded: url_helper
DEBUG - 2013-01-06 13:45:20 --> Controller Class Initialized
DEBUG - 2013-01-06 13:45:20 --> Model Class Initialized
DEBUG - 2013-01-06 13:45:20 --> Model Class Initialized
DEBUG - 2013-01-06 13:45:21 --> Database Driver Class Initialized
DEBUG - 2013-01-06 13:45:23 --> File loaded: application/views/home.php
DEBUG - 2013-01-06 13:45:23 --> Final output sent to browser
DEBUG - 2013-01-06 13:45:23 --> Total execution time: 4.3869
DEBUG - 2013-01-06 13:52:15 --> Config Class Initialized
DEBUG - 2013-01-06 13:52:15 --> Hooks Class Initialized
DEBUG - 2013-01-06 13:52:15 --> Utf8 Class Initialized
DEBUG - 2013-01-06 13:52:15 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 13:52:15 --> URI Class Initialized
DEBUG - 2013-01-06 13:52:15 --> Router Class Initialized
DEBUG - 2013-01-06 13:52:15 --> Output Class Initialized
DEBUG - 2013-01-06 13:52:15 --> Security Class Initialized
DEBUG - 2013-01-06 13:52:15 --> Input Class Initialized
DEBUG - 2013-01-06 13:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 13:52:15 --> Language Class Initialized
DEBUG - 2013-01-06 13:52:15 --> Loader Class Initialized
DEBUG - 2013-01-06 13:52:15 --> Helper loaded: url_helper
DEBUG - 2013-01-06 13:52:15 --> Controller Class Initialized
DEBUG - 2013-01-06 13:52:15 --> Model Class Initialized
DEBUG - 2013-01-06 13:52:15 --> Model Class Initialized
DEBUG - 2013-01-06 13:52:15 --> Database Driver Class Initialized
DEBUG - 2013-01-06 13:52:17 --> Final output sent to browser
DEBUG - 2013-01-06 13:52:17 --> Total execution time: 1.8281
DEBUG - 2013-01-06 13:53:29 --> Config Class Initialized
DEBUG - 2013-01-06 13:53:29 --> Hooks Class Initialized
DEBUG - 2013-01-06 13:53:29 --> Utf8 Class Initialized
DEBUG - 2013-01-06 13:53:30 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 13:53:30 --> URI Class Initialized
DEBUG - 2013-01-06 13:53:30 --> Router Class Initialized
DEBUG - 2013-01-06 13:53:30 --> Output Class Initialized
DEBUG - 2013-01-06 13:53:30 --> Security Class Initialized
DEBUG - 2013-01-06 13:53:30 --> Input Class Initialized
DEBUG - 2013-01-06 13:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 13:53:30 --> Language Class Initialized
DEBUG - 2013-01-06 13:53:30 --> Loader Class Initialized
DEBUG - 2013-01-06 13:53:30 --> Helper loaded: url_helper
DEBUG - 2013-01-06 13:53:30 --> Controller Class Initialized
DEBUG - 2013-01-06 13:53:31 --> Model Class Initialized
DEBUG - 2013-01-06 13:53:31 --> Model Class Initialized
DEBUG - 2013-01-06 13:53:31 --> Database Driver Class Initialized
DEBUG - 2013-01-06 13:53:31 --> Final output sent to browser
DEBUG - 2013-01-06 13:53:31 --> Total execution time: 1.7712
DEBUG - 2013-01-06 13:54:42 --> Config Class Initialized
DEBUG - 2013-01-06 13:54:42 --> Hooks Class Initialized
DEBUG - 2013-01-06 13:54:43 --> Utf8 Class Initialized
DEBUG - 2013-01-06 13:54:43 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 13:54:43 --> URI Class Initialized
DEBUG - 2013-01-06 13:54:43 --> Router Class Initialized
DEBUG - 2013-01-06 13:54:43 --> Output Class Initialized
DEBUG - 2013-01-06 13:54:43 --> Security Class Initialized
DEBUG - 2013-01-06 13:54:43 --> Input Class Initialized
DEBUG - 2013-01-06 13:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 13:54:43 --> Language Class Initialized
DEBUG - 2013-01-06 13:54:43 --> Loader Class Initialized
DEBUG - 2013-01-06 13:54:43 --> Helper loaded: url_helper
DEBUG - 2013-01-06 13:54:43 --> Controller Class Initialized
DEBUG - 2013-01-06 13:54:43 --> Model Class Initialized
DEBUG - 2013-01-06 13:54:44 --> Model Class Initialized
DEBUG - 2013-01-06 13:54:44 --> Database Driver Class Initialized
DEBUG - 2013-01-06 13:54:44 --> Final output sent to browser
DEBUG - 2013-01-06 13:54:44 --> Total execution time: 1.3287
DEBUG - 2013-01-06 13:55:16 --> Config Class Initialized
DEBUG - 2013-01-06 13:55:16 --> Hooks Class Initialized
DEBUG - 2013-01-06 13:55:17 --> Utf8 Class Initialized
DEBUG - 2013-01-06 13:55:17 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 13:55:17 --> URI Class Initialized
DEBUG - 2013-01-06 13:55:17 --> Router Class Initialized
DEBUG - 2013-01-06 13:55:17 --> Output Class Initialized
DEBUG - 2013-01-06 13:55:17 --> Security Class Initialized
DEBUG - 2013-01-06 13:55:17 --> Input Class Initialized
DEBUG - 2013-01-06 13:55:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 13:55:17 --> Language Class Initialized
DEBUG - 2013-01-06 13:55:17 --> Loader Class Initialized
DEBUG - 2013-01-06 13:55:17 --> Helper loaded: url_helper
DEBUG - 2013-01-06 13:55:17 --> Controller Class Initialized
DEBUG - 2013-01-06 13:55:17 --> Model Class Initialized
DEBUG - 2013-01-06 13:55:17 --> Model Class Initialized
DEBUG - 2013-01-06 13:55:17 --> Database Driver Class Initialized
DEBUG - 2013-01-06 13:55:17 --> Final output sent to browser
DEBUG - 2013-01-06 13:55:17 --> Total execution time: 1.0427
DEBUG - 2013-01-06 13:57:07 --> Config Class Initialized
DEBUG - 2013-01-06 13:57:07 --> Hooks Class Initialized
DEBUG - 2013-01-06 13:57:07 --> Utf8 Class Initialized
DEBUG - 2013-01-06 13:57:07 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 13:57:07 --> URI Class Initialized
DEBUG - 2013-01-06 13:57:07 --> Router Class Initialized
DEBUG - 2013-01-06 13:57:07 --> Output Class Initialized
DEBUG - 2013-01-06 13:57:07 --> Security Class Initialized
DEBUG - 2013-01-06 13:57:07 --> Input Class Initialized
DEBUG - 2013-01-06 13:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 13:57:07 --> Language Class Initialized
DEBUG - 2013-01-06 13:57:07 --> Loader Class Initialized
DEBUG - 2013-01-06 13:57:07 --> Helper loaded: url_helper
DEBUG - 2013-01-06 13:57:07 --> Controller Class Initialized
DEBUG - 2013-01-06 13:57:07 --> Model Class Initialized
DEBUG - 2013-01-06 13:57:07 --> Model Class Initialized
DEBUG - 2013-01-06 13:57:07 --> Database Driver Class Initialized
DEBUG - 2013-01-06 13:57:07 --> File loaded: application/views/register.php
DEBUG - 2013-01-06 13:57:07 --> Final output sent to browser
DEBUG - 2013-01-06 13:57:07 --> Total execution time: 0.4238
DEBUG - 2013-01-06 13:57:08 --> Config Class Initialized
DEBUG - 2013-01-06 13:57:08 --> Hooks Class Initialized
DEBUG - 2013-01-06 13:57:08 --> Utf8 Class Initialized
DEBUG - 2013-01-06 13:57:08 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 13:57:08 --> URI Class Initialized
DEBUG - 2013-01-06 13:57:08 --> Router Class Initialized
ERROR - 2013-01-06 13:57:08 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-06 13:57:32 --> Config Class Initialized
DEBUG - 2013-01-06 13:57:32 --> Hooks Class Initialized
DEBUG - 2013-01-06 13:57:32 --> Utf8 Class Initialized
DEBUG - 2013-01-06 13:57:32 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 13:57:32 --> URI Class Initialized
DEBUG - 2013-01-06 13:57:32 --> Router Class Initialized
DEBUG - 2013-01-06 13:57:32 --> Output Class Initialized
DEBUG - 2013-01-06 13:57:32 --> Security Class Initialized
DEBUG - 2013-01-06 13:57:32 --> Input Class Initialized
DEBUG - 2013-01-06 13:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 13:57:32 --> Language Class Initialized
DEBUG - 2013-01-06 13:57:32 --> Loader Class Initialized
DEBUG - 2013-01-06 13:57:32 --> Helper loaded: url_helper
DEBUG - 2013-01-06 13:57:32 --> Controller Class Initialized
DEBUG - 2013-01-06 13:57:32 --> Model Class Initialized
DEBUG - 2013-01-06 13:57:32 --> Model Class Initialized
DEBUG - 2013-01-06 13:57:33 --> Database Driver Class Initialized
DEBUG - 2013-01-06 13:57:33 --> Final output sent to browser
DEBUG - 2013-01-06 13:57:33 --> Total execution time: 0.8590
DEBUG - 2013-01-06 13:58:18 --> Config Class Initialized
DEBUG - 2013-01-06 13:58:18 --> Hooks Class Initialized
DEBUG - 2013-01-06 13:58:18 --> Utf8 Class Initialized
DEBUG - 2013-01-06 13:58:18 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 13:58:18 --> URI Class Initialized
DEBUG - 2013-01-06 13:58:19 --> Router Class Initialized
DEBUG - 2013-01-06 13:58:19 --> Output Class Initialized
DEBUG - 2013-01-06 13:58:19 --> Security Class Initialized
DEBUG - 2013-01-06 13:58:19 --> Input Class Initialized
DEBUG - 2013-01-06 13:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 13:58:19 --> Language Class Initialized
DEBUG - 2013-01-06 13:58:19 --> Loader Class Initialized
DEBUG - 2013-01-06 13:58:19 --> Helper loaded: url_helper
DEBUG - 2013-01-06 13:58:19 --> Controller Class Initialized
DEBUG - 2013-01-06 13:58:19 --> Model Class Initialized
DEBUG - 2013-01-06 13:58:19 --> Model Class Initialized
DEBUG - 2013-01-06 13:58:19 --> Database Driver Class Initialized
DEBUG - 2013-01-06 13:58:20 --> Final output sent to browser
DEBUG - 2013-01-06 13:58:20 --> Total execution time: 1.6384
DEBUG - 2013-01-06 13:58:46 --> Config Class Initialized
DEBUG - 2013-01-06 13:58:46 --> Hooks Class Initialized
DEBUG - 2013-01-06 13:58:46 --> Utf8 Class Initialized
DEBUG - 2013-01-06 13:58:46 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 13:58:46 --> URI Class Initialized
DEBUG - 2013-01-06 13:58:46 --> Router Class Initialized
DEBUG - 2013-01-06 13:58:46 --> Output Class Initialized
DEBUG - 2013-01-06 13:58:46 --> Security Class Initialized
DEBUG - 2013-01-06 13:58:46 --> Input Class Initialized
DEBUG - 2013-01-06 13:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 13:58:46 --> Language Class Initialized
DEBUG - 2013-01-06 13:58:47 --> Loader Class Initialized
DEBUG - 2013-01-06 13:58:47 --> Helper loaded: url_helper
DEBUG - 2013-01-06 13:58:47 --> Controller Class Initialized
DEBUG - 2013-01-06 13:58:47 --> Model Class Initialized
DEBUG - 2013-01-06 13:58:47 --> Model Class Initialized
DEBUG - 2013-01-06 13:58:47 --> Database Driver Class Initialized
DEBUG - 2013-01-06 13:58:47 --> Final output sent to browser
DEBUG - 2013-01-06 13:58:47 --> Total execution time: 0.7090
DEBUG - 2013-01-06 14:00:13 --> Config Class Initialized
DEBUG - 2013-01-06 14:00:13 --> Hooks Class Initialized
DEBUG - 2013-01-06 14:00:13 --> Utf8 Class Initialized
DEBUG - 2013-01-06 14:00:13 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 14:00:13 --> URI Class Initialized
DEBUG - 2013-01-06 14:00:13 --> Router Class Initialized
DEBUG - 2013-01-06 14:00:13 --> Output Class Initialized
DEBUG - 2013-01-06 14:00:13 --> Security Class Initialized
DEBUG - 2013-01-06 14:00:13 --> Input Class Initialized
DEBUG - 2013-01-06 14:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 14:00:13 --> Language Class Initialized
DEBUG - 2013-01-06 14:00:13 --> Loader Class Initialized
DEBUG - 2013-01-06 14:00:13 --> Helper loaded: url_helper
DEBUG - 2013-01-06 14:00:13 --> Controller Class Initialized
DEBUG - 2013-01-06 14:00:13 --> Model Class Initialized
DEBUG - 2013-01-06 14:00:13 --> Model Class Initialized
DEBUG - 2013-01-06 14:00:13 --> Database Driver Class Initialized
DEBUG - 2013-01-06 14:00:13 --> Final output sent to browser
DEBUG - 2013-01-06 14:00:13 --> Total execution time: 0.2710
DEBUG - 2013-01-06 14:00:32 --> Config Class Initialized
DEBUG - 2013-01-06 14:00:32 --> Hooks Class Initialized
DEBUG - 2013-01-06 14:00:32 --> Utf8 Class Initialized
DEBUG - 2013-01-06 14:00:32 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 14:00:32 --> URI Class Initialized
DEBUG - 2013-01-06 14:00:32 --> Router Class Initialized
DEBUG - 2013-01-06 14:00:32 --> Output Class Initialized
DEBUG - 2013-01-06 14:00:32 --> Security Class Initialized
DEBUG - 2013-01-06 14:00:32 --> Input Class Initialized
DEBUG - 2013-01-06 14:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 14:00:33 --> Language Class Initialized
DEBUG - 2013-01-06 14:00:33 --> Loader Class Initialized
DEBUG - 2013-01-06 14:00:33 --> Helper loaded: url_helper
DEBUG - 2013-01-06 14:00:33 --> Controller Class Initialized
DEBUG - 2013-01-06 14:00:33 --> Model Class Initialized
DEBUG - 2013-01-06 14:00:33 --> Model Class Initialized
DEBUG - 2013-01-06 14:00:33 --> Database Driver Class Initialized
DEBUG - 2013-01-06 14:00:33 --> Final output sent to browser
DEBUG - 2013-01-06 14:00:33 --> Total execution time: 1.0192
DEBUG - 2013-01-06 14:04:51 --> Config Class Initialized
DEBUG - 2013-01-06 14:04:51 --> Hooks Class Initialized
DEBUG - 2013-01-06 14:04:51 --> Utf8 Class Initialized
DEBUG - 2013-01-06 14:04:51 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 14:04:51 --> URI Class Initialized
DEBUG - 2013-01-06 14:04:51 --> Router Class Initialized
DEBUG - 2013-01-06 14:04:51 --> Output Class Initialized
DEBUG - 2013-01-06 14:04:51 --> Security Class Initialized
DEBUG - 2013-01-06 14:04:51 --> Input Class Initialized
DEBUG - 2013-01-06 14:04:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 14:04:51 --> Language Class Initialized
DEBUG - 2013-01-06 14:04:51 --> Loader Class Initialized
DEBUG - 2013-01-06 14:04:51 --> Helper loaded: url_helper
DEBUG - 2013-01-06 14:04:51 --> Controller Class Initialized
DEBUG - 2013-01-06 14:04:51 --> Model Class Initialized
DEBUG - 2013-01-06 14:04:51 --> Model Class Initialized
DEBUG - 2013-01-06 14:04:51 --> Database Driver Class Initialized
DEBUG - 2013-01-06 14:04:51 --> Final output sent to browser
DEBUG - 2013-01-06 14:04:51 --> Total execution time: 0.4377
DEBUG - 2013-01-06 14:09:10 --> Config Class Initialized
DEBUG - 2013-01-06 14:09:10 --> Hooks Class Initialized
DEBUG - 2013-01-06 14:09:10 --> Utf8 Class Initialized
DEBUG - 2013-01-06 14:09:10 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 14:09:10 --> URI Class Initialized
DEBUG - 2013-01-06 14:09:10 --> Router Class Initialized
DEBUG - 2013-01-06 14:09:10 --> Output Class Initialized
DEBUG - 2013-01-06 14:09:10 --> Security Class Initialized
DEBUG - 2013-01-06 14:09:10 --> Input Class Initialized
DEBUG - 2013-01-06 14:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 14:09:10 --> Language Class Initialized
DEBUG - 2013-01-06 14:09:10 --> Loader Class Initialized
DEBUG - 2013-01-06 14:09:10 --> Helper loaded: url_helper
DEBUG - 2013-01-06 14:09:10 --> Controller Class Initialized
DEBUG - 2013-01-06 14:09:10 --> Model Class Initialized
DEBUG - 2013-01-06 14:09:10 --> Model Class Initialized
DEBUG - 2013-01-06 14:09:10 --> Database Driver Class Initialized
DEBUG - 2013-01-06 14:09:10 --> Final output sent to browser
DEBUG - 2013-01-06 14:09:10 --> Total execution time: 0.2720
DEBUG - 2013-01-06 14:09:49 --> Config Class Initialized
DEBUG - 2013-01-06 14:09:49 --> Hooks Class Initialized
DEBUG - 2013-01-06 14:09:49 --> Utf8 Class Initialized
DEBUG - 2013-01-06 14:09:49 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 14:09:49 --> URI Class Initialized
DEBUG - 2013-01-06 14:09:49 --> Router Class Initialized
DEBUG - 2013-01-06 14:09:49 --> Output Class Initialized
DEBUG - 2013-01-06 14:09:49 --> Security Class Initialized
DEBUG - 2013-01-06 14:09:49 --> Input Class Initialized
DEBUG - 2013-01-06 14:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 14:09:49 --> Language Class Initialized
DEBUG - 2013-01-06 14:09:49 --> Loader Class Initialized
DEBUG - 2013-01-06 14:09:49 --> Helper loaded: url_helper
DEBUG - 2013-01-06 14:09:49 --> Controller Class Initialized
DEBUG - 2013-01-06 14:09:49 --> Model Class Initialized
DEBUG - 2013-01-06 14:09:49 --> Model Class Initialized
DEBUG - 2013-01-06 14:09:49 --> Database Driver Class Initialized
DEBUG - 2013-01-06 14:09:49 --> Final output sent to browser
DEBUG - 2013-01-06 14:09:49 --> Total execution time: 0.2476
DEBUG - 2013-01-06 14:10:18 --> Config Class Initialized
DEBUG - 2013-01-06 14:10:18 --> Hooks Class Initialized
DEBUG - 2013-01-06 14:10:18 --> Utf8 Class Initialized
DEBUG - 2013-01-06 14:10:18 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 14:10:18 --> URI Class Initialized
DEBUG - 2013-01-06 14:10:18 --> Router Class Initialized
DEBUG - 2013-01-06 14:10:18 --> Output Class Initialized
DEBUG - 2013-01-06 14:10:18 --> Security Class Initialized
DEBUG - 2013-01-06 14:10:18 --> Input Class Initialized
DEBUG - 2013-01-06 14:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 14:10:18 --> Language Class Initialized
DEBUG - 2013-01-06 14:10:18 --> Loader Class Initialized
DEBUG - 2013-01-06 14:10:18 --> Helper loaded: url_helper
DEBUG - 2013-01-06 14:10:18 --> Controller Class Initialized
DEBUG - 2013-01-06 14:10:18 --> Model Class Initialized
DEBUG - 2013-01-06 14:10:18 --> Model Class Initialized
DEBUG - 2013-01-06 14:10:18 --> Database Driver Class Initialized
DEBUG - 2013-01-06 14:10:18 --> Final output sent to browser
DEBUG - 2013-01-06 14:10:18 --> Total execution time: 0.2598
DEBUG - 2013-01-06 14:11:08 --> Config Class Initialized
DEBUG - 2013-01-06 14:11:08 --> Hooks Class Initialized
DEBUG - 2013-01-06 14:11:08 --> Utf8 Class Initialized
DEBUG - 2013-01-06 14:11:08 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 14:11:08 --> URI Class Initialized
DEBUG - 2013-01-06 14:11:08 --> Router Class Initialized
DEBUG - 2013-01-06 14:11:08 --> Output Class Initialized
DEBUG - 2013-01-06 14:11:08 --> Security Class Initialized
DEBUG - 2013-01-06 14:11:08 --> Input Class Initialized
DEBUG - 2013-01-06 14:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 14:11:08 --> Language Class Initialized
DEBUG - 2013-01-06 14:11:08 --> Loader Class Initialized
DEBUG - 2013-01-06 14:11:08 --> Helper loaded: url_helper
DEBUG - 2013-01-06 14:11:08 --> Controller Class Initialized
DEBUG - 2013-01-06 14:11:08 --> Model Class Initialized
DEBUG - 2013-01-06 14:11:08 --> Model Class Initialized
DEBUG - 2013-01-06 14:11:08 --> Database Driver Class Initialized
DEBUG - 2013-01-06 14:11:08 --> Final output sent to browser
DEBUG - 2013-01-06 14:11:08 --> Total execution time: 0.4274
DEBUG - 2013-01-06 14:11:38 --> Config Class Initialized
DEBUG - 2013-01-06 14:11:38 --> Hooks Class Initialized
DEBUG - 2013-01-06 14:11:38 --> Utf8 Class Initialized
DEBUG - 2013-01-06 14:11:38 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 14:11:38 --> URI Class Initialized
DEBUG - 2013-01-06 14:11:38 --> Router Class Initialized
DEBUG - 2013-01-06 14:11:38 --> Output Class Initialized
DEBUG - 2013-01-06 14:11:38 --> Security Class Initialized
DEBUG - 2013-01-06 14:11:38 --> Input Class Initialized
DEBUG - 2013-01-06 14:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 14:11:38 --> Language Class Initialized
DEBUG - 2013-01-06 14:11:38 --> Loader Class Initialized
DEBUG - 2013-01-06 14:11:38 --> Helper loaded: url_helper
DEBUG - 2013-01-06 14:11:38 --> Controller Class Initialized
DEBUG - 2013-01-06 14:11:38 --> Model Class Initialized
DEBUG - 2013-01-06 14:11:38 --> Model Class Initialized
DEBUG - 2013-01-06 14:11:38 --> Database Driver Class Initialized
DEBUG - 2013-01-06 14:11:38 --> Final output sent to browser
DEBUG - 2013-01-06 14:11:38 --> Total execution time: 0.2146
DEBUG - 2013-01-06 14:12:17 --> Config Class Initialized
DEBUG - 2013-01-06 14:12:17 --> Hooks Class Initialized
DEBUG - 2013-01-06 14:12:17 --> Utf8 Class Initialized
DEBUG - 2013-01-06 14:12:17 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 14:12:17 --> URI Class Initialized
DEBUG - 2013-01-06 14:12:17 --> Router Class Initialized
DEBUG - 2013-01-06 14:12:17 --> Output Class Initialized
DEBUG - 2013-01-06 14:12:17 --> Security Class Initialized
DEBUG - 2013-01-06 14:12:17 --> Input Class Initialized
DEBUG - 2013-01-06 14:12:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 14:12:17 --> Language Class Initialized
DEBUG - 2013-01-06 14:12:17 --> Loader Class Initialized
DEBUG - 2013-01-06 14:12:17 --> Helper loaded: url_helper
DEBUG - 2013-01-06 14:12:17 --> Controller Class Initialized
DEBUG - 2013-01-06 14:12:17 --> Model Class Initialized
DEBUG - 2013-01-06 14:12:17 --> Model Class Initialized
DEBUG - 2013-01-06 14:12:18 --> Database Driver Class Initialized
DEBUG - 2013-01-06 14:12:18 --> Final output sent to browser
DEBUG - 2013-01-06 14:12:18 --> Total execution time: 0.1810
DEBUG - 2013-01-06 17:51:24 --> Config Class Initialized
DEBUG - 2013-01-06 17:51:25 --> Hooks Class Initialized
DEBUG - 2013-01-06 17:51:25 --> Utf8 Class Initialized
DEBUG - 2013-01-06 17:51:25 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 17:51:25 --> URI Class Initialized
DEBUG - 2013-01-06 17:51:25 --> Router Class Initialized
DEBUG - 2013-01-06 17:51:25 --> Output Class Initialized
DEBUG - 2013-01-06 17:51:25 --> Security Class Initialized
DEBUG - 2013-01-06 17:51:25 --> Input Class Initialized
DEBUG - 2013-01-06 17:51:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 17:51:25 --> Language Class Initialized
DEBUG - 2013-01-06 17:51:25 --> Loader Class Initialized
DEBUG - 2013-01-06 17:51:25 --> Helper loaded: url_helper
DEBUG - 2013-01-06 17:51:25 --> Controller Class Initialized
DEBUG - 2013-01-06 17:51:25 --> Model Class Initialized
DEBUG - 2013-01-06 17:51:25 --> Model Class Initialized
DEBUG - 2013-01-06 17:51:25 --> Database Driver Class Initialized
DEBUG - 2013-01-06 17:51:25 --> Final output sent to browser
DEBUG - 2013-01-06 17:51:25 --> Total execution time: 0.8177
DEBUG - 2013-01-06 17:51:53 --> Config Class Initialized
DEBUG - 2013-01-06 17:51:53 --> Hooks Class Initialized
DEBUG - 2013-01-06 17:51:53 --> Utf8 Class Initialized
DEBUG - 2013-01-06 17:51:53 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 17:51:53 --> URI Class Initialized
DEBUG - 2013-01-06 17:51:53 --> Router Class Initialized
DEBUG - 2013-01-06 17:51:53 --> Output Class Initialized
DEBUG - 2013-01-06 17:51:53 --> Security Class Initialized
DEBUG - 2013-01-06 17:51:53 --> Input Class Initialized
DEBUG - 2013-01-06 17:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 17:51:53 --> Language Class Initialized
DEBUG - 2013-01-06 17:51:53 --> Loader Class Initialized
DEBUG - 2013-01-06 17:51:53 --> Helper loaded: url_helper
DEBUG - 2013-01-06 17:51:53 --> Controller Class Initialized
DEBUG - 2013-01-06 17:51:53 --> Model Class Initialized
DEBUG - 2013-01-06 17:51:53 --> Model Class Initialized
DEBUG - 2013-01-06 17:51:53 --> Database Driver Class Initialized
DEBUG - 2013-01-06 17:51:53 --> Final output sent to browser
DEBUG - 2013-01-06 17:51:53 --> Total execution time: 0.1926
DEBUG - 2013-01-06 17:52:40 --> Config Class Initialized
DEBUG - 2013-01-06 17:52:40 --> Hooks Class Initialized
DEBUG - 2013-01-06 17:52:40 --> Utf8 Class Initialized
DEBUG - 2013-01-06 17:52:40 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 17:52:40 --> URI Class Initialized
DEBUG - 2013-01-06 17:52:40 --> Router Class Initialized
DEBUG - 2013-01-06 17:52:40 --> Output Class Initialized
DEBUG - 2013-01-06 17:52:40 --> Security Class Initialized
DEBUG - 2013-01-06 17:52:40 --> Input Class Initialized
DEBUG - 2013-01-06 17:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 17:52:40 --> Language Class Initialized
DEBUG - 2013-01-06 17:52:40 --> Loader Class Initialized
DEBUG - 2013-01-06 17:52:40 --> Helper loaded: url_helper
DEBUG - 2013-01-06 17:52:40 --> Controller Class Initialized
DEBUG - 2013-01-06 17:52:40 --> Model Class Initialized
DEBUG - 2013-01-06 17:52:40 --> Model Class Initialized
DEBUG - 2013-01-06 17:52:40 --> Database Driver Class Initialized
DEBUG - 2013-01-06 17:52:40 --> Final output sent to browser
DEBUG - 2013-01-06 17:52:40 --> Total execution time: 0.1925
DEBUG - 2013-01-06 17:52:56 --> Config Class Initialized
DEBUG - 2013-01-06 17:52:56 --> Hooks Class Initialized
DEBUG - 2013-01-06 17:52:56 --> Utf8 Class Initialized
DEBUG - 2013-01-06 17:52:56 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 17:52:56 --> URI Class Initialized
DEBUG - 2013-01-06 17:52:56 --> Router Class Initialized
DEBUG - 2013-01-06 17:52:56 --> Output Class Initialized
DEBUG - 2013-01-06 17:52:56 --> Security Class Initialized
DEBUG - 2013-01-06 17:52:56 --> Input Class Initialized
DEBUG - 2013-01-06 17:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 17:52:56 --> Language Class Initialized
DEBUG - 2013-01-06 17:52:56 --> Loader Class Initialized
DEBUG - 2013-01-06 17:52:56 --> Helper loaded: url_helper
DEBUG - 2013-01-06 17:52:56 --> Controller Class Initialized
DEBUG - 2013-01-06 17:52:56 --> Model Class Initialized
DEBUG - 2013-01-06 17:52:56 --> Model Class Initialized
DEBUG - 2013-01-06 17:52:56 --> Database Driver Class Initialized
DEBUG - 2013-01-06 17:52:56 --> Final output sent to browser
DEBUG - 2013-01-06 17:52:56 --> Total execution time: 0.2116
DEBUG - 2013-01-06 17:53:02 --> Config Class Initialized
DEBUG - 2013-01-06 17:53:02 --> Hooks Class Initialized
DEBUG - 2013-01-06 17:53:02 --> Utf8 Class Initialized
DEBUG - 2013-01-06 17:53:02 --> UTF-8 Support Enabled
DEBUG - 2013-01-06 17:53:02 --> URI Class Initialized
DEBUG - 2013-01-06 17:53:02 --> Router Class Initialized
DEBUG - 2013-01-06 17:53:02 --> Output Class Initialized
DEBUG - 2013-01-06 17:53:02 --> Security Class Initialized
DEBUG - 2013-01-06 17:53:02 --> Input Class Initialized
DEBUG - 2013-01-06 17:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-06 17:53:02 --> Language Class Initialized
DEBUG - 2013-01-06 17:53:02 --> Loader Class Initialized
DEBUG - 2013-01-06 17:53:02 --> Helper loaded: url_helper
DEBUG - 2013-01-06 17:53:02 --> Controller Class Initialized
DEBUG - 2013-01-06 17:53:02 --> Model Class Initialized
DEBUG - 2013-01-06 17:53:02 --> Model Class Initialized
DEBUG - 2013-01-06 17:53:02 --> Database Driver Class Initialized
DEBUG - 2013-01-06 17:53:03 --> Final output sent to browser
DEBUG - 2013-01-06 17:53:03 --> Total execution time: 0.2310

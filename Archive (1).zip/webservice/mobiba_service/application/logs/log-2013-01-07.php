<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-01-07 07:43:19 --> Config Class Initialized
DEBUG - 2013-01-07 07:43:19 --> Hooks Class Initialized
DEBUG - 2013-01-07 07:43:19 --> Utf8 Class Initialized
DEBUG - 2013-01-07 07:43:19 --> UTF-8 Support Enabled
DEBUG - 2013-01-07 07:43:19 --> URI Class Initialized
DEBUG - 2013-01-07 07:43:19 --> Router Class Initialized
DEBUG - 2013-01-07 07:43:19 --> No URI present. Default controller set.
DEBUG - 2013-01-07 07:43:19 --> Output Class Initialized
DEBUG - 2013-01-07 07:43:19 --> Security Class Initialized
DEBUG - 2013-01-07 07:43:19 --> Input Class Initialized
DEBUG - 2013-01-07 07:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-07 07:43:19 --> Language Class Initialized
DEBUG - 2013-01-07 07:43:19 --> Loader Class Initialized
DEBUG - 2013-01-07 07:43:19 --> Helper loaded: url_helper
DEBUG - 2013-01-07 07:43:19 --> Controller Class Initialized
DEBUG - 2013-01-07 07:43:19 --> Model Class Initialized
DEBUG - 2013-01-07 07:43:20 --> Model Class Initialized
DEBUG - 2013-01-07 07:43:20 --> Database Driver Class Initialized
DEBUG - 2013-01-07 07:43:20 --> File loaded: application/views/home.php
DEBUG - 2013-01-07 07:43:20 --> Final output sent to browser
DEBUG - 2013-01-07 07:43:20 --> Total execution time: 0.4713
DEBUG - 2013-01-07 07:43:22 --> Config Class Initialized
DEBUG - 2013-01-07 07:43:22 --> Hooks Class Initialized
DEBUG - 2013-01-07 07:43:22 --> Utf8 Class Initialized
DEBUG - 2013-01-07 07:43:22 --> UTF-8 Support Enabled
DEBUG - 2013-01-07 07:43:22 --> URI Class Initialized
DEBUG - 2013-01-07 07:43:22 --> Router Class Initialized
DEBUG - 2013-01-07 07:43:22 --> Output Class Initialized
DEBUG - 2013-01-07 07:43:22 --> Security Class Initialized
DEBUG - 2013-01-07 07:43:22 --> Input Class Initialized
DEBUG - 2013-01-07 07:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-07 07:43:22 --> Language Class Initialized
DEBUG - 2013-01-07 07:43:22 --> Loader Class Initialized
DEBUG - 2013-01-07 07:43:22 --> Helper loaded: url_helper
DEBUG - 2013-01-07 07:43:22 --> Controller Class Initialized
DEBUG - 2013-01-07 07:43:22 --> Model Class Initialized
DEBUG - 2013-01-07 07:43:22 --> Model Class Initialized
DEBUG - 2013-01-07 07:43:22 --> Database Driver Class Initialized
DEBUG - 2013-01-07 07:43:22 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-07 07:43:22 --> Final output sent to browser
DEBUG - 2013-01-07 07:43:22 --> Total execution time: 0.2178
DEBUG - 2013-01-07 07:43:22 --> Config Class Initialized
DEBUG - 2013-01-07 07:43:22 --> Hooks Class Initialized
DEBUG - 2013-01-07 07:43:22 --> Utf8 Class Initialized
DEBUG - 2013-01-07 07:43:22 --> UTF-8 Support Enabled
DEBUG - 2013-01-07 07:43:22 --> URI Class Initialized
DEBUG - 2013-01-07 07:43:22 --> Router Class Initialized
ERROR - 2013-01-07 07:43:22 --> 404 Page Not Found --> getExcel

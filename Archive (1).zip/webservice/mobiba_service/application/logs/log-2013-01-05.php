<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-01-05 06:38:28 --> Config Class Initialized
DEBUG - 2013-01-05 06:38:28 --> Hooks Class Initialized
DEBUG - 2013-01-05 06:38:28 --> Utf8 Class Initialized
DEBUG - 2013-01-05 06:38:28 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 06:38:28 --> URI Class Initialized
DEBUG - 2013-01-05 06:38:28 --> Router Class Initialized
DEBUG - 2013-01-05 06:38:28 --> No URI present. Default controller set.
DEBUG - 2013-01-05 06:38:28 --> Output Class Initialized
DEBUG - 2013-01-05 06:38:28 --> Security Class Initialized
DEBUG - 2013-01-05 06:38:28 --> Input Class Initialized
DEBUG - 2013-01-05 06:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 06:38:28 --> Language Class Initialized
DEBUG - 2013-01-05 06:38:29 --> Loader Class Initialized
DEBUG - 2013-01-05 06:38:29 --> Helper loaded: url_helper
DEBUG - 2013-01-05 06:38:29 --> Controller Class Initialized
DEBUG - 2013-01-05 06:38:29 --> Model Class Initialized
DEBUG - 2013-01-05 06:38:29 --> Model Class Initialized
DEBUG - 2013-01-05 06:38:29 --> Database Driver Class Initialized
ERROR - 2013-01-05 06:38:29 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: YES) C:\wamp\www\mobiba_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-01-05 06:38:29 --> Unable to connect to the database
DEBUG - 2013-01-05 06:38:29 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 06:38:29 --> Final output sent to browser
DEBUG - 2013-01-05 06:38:29 --> Total execution time: 0.3936
DEBUG - 2013-01-05 06:40:21 --> Config Class Initialized
DEBUG - 2013-01-05 06:40:21 --> Hooks Class Initialized
DEBUG - 2013-01-05 06:40:21 --> Utf8 Class Initialized
DEBUG - 2013-01-05 06:40:21 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 06:40:21 --> URI Class Initialized
DEBUG - 2013-01-05 06:40:21 --> Router Class Initialized
DEBUG - 2013-01-05 06:40:21 --> No URI present. Default controller set.
DEBUG - 2013-01-05 06:40:21 --> Output Class Initialized
DEBUG - 2013-01-05 06:40:21 --> Security Class Initialized
DEBUG - 2013-01-05 06:40:21 --> Input Class Initialized
DEBUG - 2013-01-05 06:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 06:40:21 --> Language Class Initialized
DEBUG - 2013-01-05 06:40:21 --> Loader Class Initialized
DEBUG - 2013-01-05 06:40:21 --> Helper loaded: url_helper
DEBUG - 2013-01-05 06:40:21 --> Controller Class Initialized
DEBUG - 2013-01-05 06:40:21 --> Model Class Initialized
DEBUG - 2013-01-05 06:40:21 --> Model Class Initialized
DEBUG - 2013-01-05 06:40:21 --> Database Driver Class Initialized
ERROR - 2013-01-05 06:40:21 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: YES) C:\wamp\www\mobiba_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-01-05 06:40:21 --> Unable to connect to the database
DEBUG - 2013-01-05 06:40:21 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 06:40:21 --> Final output sent to browser
DEBUG - 2013-01-05 06:40:21 --> Total execution time: 0.2087
DEBUG - 2013-01-05 06:43:45 --> Config Class Initialized
DEBUG - 2013-01-05 06:43:45 --> Hooks Class Initialized
DEBUG - 2013-01-05 06:43:45 --> Utf8 Class Initialized
DEBUG - 2013-01-05 06:43:45 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 06:43:45 --> URI Class Initialized
DEBUG - 2013-01-05 06:43:45 --> Router Class Initialized
DEBUG - 2013-01-05 06:43:45 --> No URI present. Default controller set.
DEBUG - 2013-01-05 06:43:45 --> Output Class Initialized
DEBUG - 2013-01-05 06:43:45 --> Security Class Initialized
DEBUG - 2013-01-05 06:43:45 --> Input Class Initialized
DEBUG - 2013-01-05 06:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 06:43:45 --> Language Class Initialized
DEBUG - 2013-01-05 06:43:45 --> Loader Class Initialized
DEBUG - 2013-01-05 06:43:45 --> Helper loaded: url_helper
DEBUG - 2013-01-05 06:43:45 --> Controller Class Initialized
DEBUG - 2013-01-05 06:43:45 --> Model Class Initialized
DEBUG - 2013-01-05 06:43:45 --> Model Class Initialized
DEBUG - 2013-01-05 06:43:45 --> Database Driver Class Initialized
DEBUG - 2013-01-05 06:43:45 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 06:43:45 --> Final output sent to browser
DEBUG - 2013-01-05 06:43:45 --> Total execution time: 0.1852
DEBUG - 2013-01-05 07:30:46 --> Config Class Initialized
DEBUG - 2013-01-05 07:30:46 --> Hooks Class Initialized
DEBUG - 2013-01-05 07:30:46 --> Utf8 Class Initialized
DEBUG - 2013-01-05 07:30:46 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 07:30:46 --> URI Class Initialized
DEBUG - 2013-01-05 07:30:46 --> Router Class Initialized
DEBUG - 2013-01-05 07:30:46 --> No URI present. Default controller set.
DEBUG - 2013-01-05 07:30:46 --> Output Class Initialized
DEBUG - 2013-01-05 07:30:46 --> Security Class Initialized
DEBUG - 2013-01-05 07:30:46 --> Input Class Initialized
DEBUG - 2013-01-05 07:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 07:30:46 --> Language Class Initialized
DEBUG - 2013-01-05 07:30:46 --> Loader Class Initialized
DEBUG - 2013-01-05 07:30:46 --> Helper loaded: url_helper
DEBUG - 2013-01-05 07:30:46 --> Controller Class Initialized
DEBUG - 2013-01-05 07:30:46 --> Model Class Initialized
DEBUG - 2013-01-05 07:30:46 --> Model Class Initialized
DEBUG - 2013-01-05 07:30:46 --> Database Driver Class Initialized
DEBUG - 2013-01-05 07:30:46 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 07:30:46 --> Final output sent to browser
DEBUG - 2013-01-05 07:30:46 --> Total execution time: 0.3165
DEBUG - 2013-01-05 07:45:16 --> Config Class Initialized
DEBUG - 2013-01-05 07:45:16 --> Hooks Class Initialized
DEBUG - 2013-01-05 07:45:16 --> Utf8 Class Initialized
DEBUG - 2013-01-05 07:45:16 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 07:45:16 --> URI Class Initialized
DEBUG - 2013-01-05 07:45:16 --> Router Class Initialized
DEBUG - 2013-01-05 07:45:16 --> No URI present. Default controller set.
DEBUG - 2013-01-05 07:45:16 --> Output Class Initialized
DEBUG - 2013-01-05 07:45:16 --> Security Class Initialized
DEBUG - 2013-01-05 07:45:16 --> Input Class Initialized
DEBUG - 2013-01-05 07:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 07:45:16 --> Language Class Initialized
DEBUG - 2013-01-05 07:45:16 --> Loader Class Initialized
DEBUG - 2013-01-05 07:45:16 --> Helper loaded: url_helper
DEBUG - 2013-01-05 07:45:16 --> Controller Class Initialized
DEBUG - 2013-01-05 07:45:16 --> Model Class Initialized
DEBUG - 2013-01-05 07:45:16 --> Model Class Initialized
DEBUG - 2013-01-05 07:45:17 --> Database Driver Class Initialized
DEBUG - 2013-01-05 07:45:17 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 07:45:17 --> Final output sent to browser
DEBUG - 2013-01-05 07:45:17 --> Total execution time: 1.4409
DEBUG - 2013-01-05 07:48:02 --> Config Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Hooks Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Utf8 Class Initialized
DEBUG - 2013-01-05 07:48:02 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 07:48:02 --> URI Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Router Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Output Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Security Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Input Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 07:48:02 --> Language Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Loader Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Helper loaded: url_helper
DEBUG - 2013-01-05 07:48:02 --> Controller Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Model Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Model Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Database Driver Class Initialized
DEBUG - 2013-01-05 07:48:02 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-05 07:48:02 --> Final output sent to browser
DEBUG - 2013-01-05 07:48:02 --> Total execution time: 0.2863
DEBUG - 2013-01-05 07:48:02 --> Config Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Hooks Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Utf8 Class Initialized
DEBUG - 2013-01-05 07:48:02 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 07:48:02 --> URI Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Router Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Output Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Security Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Input Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 07:48:02 --> Language Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Loader Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Helper loaded: url_helper
DEBUG - 2013-01-05 07:48:02 --> Controller Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Model Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Model Class Initialized
DEBUG - 2013-01-05 07:48:02 --> Database Driver Class Initialized
ERROR - 2013-01-05 07:48:02 --> 404 Page Not Found --> mobiba_controller/js
DEBUG - 2013-01-05 07:48:03 --> Config Class Initialized
DEBUG - 2013-01-05 07:48:03 --> Hooks Class Initialized
DEBUG - 2013-01-05 07:48:03 --> Utf8 Class Initialized
DEBUG - 2013-01-05 07:48:03 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 07:48:03 --> URI Class Initialized
DEBUG - 2013-01-05 07:48:03 --> Router Class Initialized
DEBUG - 2013-01-05 07:48:03 --> Output Class Initialized
DEBUG - 2013-01-05 07:48:03 --> Security Class Initialized
DEBUG - 2013-01-05 07:48:03 --> Input Class Initialized
DEBUG - 2013-01-05 07:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 07:48:03 --> Language Class Initialized
DEBUG - 2013-01-05 07:48:03 --> Loader Class Initialized
DEBUG - 2013-01-05 07:48:03 --> Helper loaded: url_helper
DEBUG - 2013-01-05 07:48:03 --> Controller Class Initialized
DEBUG - 2013-01-05 07:48:03 --> Model Class Initialized
DEBUG - 2013-01-05 07:48:03 --> Model Class Initialized
DEBUG - 2013-01-05 07:48:03 --> Database Driver Class Initialized
ERROR - 2013-01-05 07:48:03 --> 404 Page Not Found --> mobiba_controller/getExcel
DEBUG - 2013-01-05 07:48:45 --> Config Class Initialized
DEBUG - 2013-01-05 07:48:45 --> Hooks Class Initialized
DEBUG - 2013-01-05 07:48:45 --> Utf8 Class Initialized
DEBUG - 2013-01-05 07:48:45 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 07:48:45 --> URI Class Initialized
DEBUG - 2013-01-05 07:48:46 --> Router Class Initialized
DEBUG - 2013-01-05 07:48:46 --> No URI present. Default controller set.
DEBUG - 2013-01-05 07:48:46 --> Output Class Initialized
DEBUG - 2013-01-05 07:48:46 --> Security Class Initialized
DEBUG - 2013-01-05 07:48:46 --> Input Class Initialized
DEBUG - 2013-01-05 07:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 07:48:46 --> Language Class Initialized
DEBUG - 2013-01-05 07:48:46 --> Loader Class Initialized
DEBUG - 2013-01-05 07:48:46 --> Helper loaded: url_helper
DEBUG - 2013-01-05 07:48:46 --> Controller Class Initialized
DEBUG - 2013-01-05 07:48:46 --> Model Class Initialized
DEBUG - 2013-01-05 07:48:46 --> Model Class Initialized
DEBUG - 2013-01-05 07:48:46 --> Database Driver Class Initialized
DEBUG - 2013-01-05 07:48:46 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 07:48:46 --> Final output sent to browser
DEBUG - 2013-01-05 07:48:46 --> Total execution time: 0.6749
DEBUG - 2013-01-05 07:54:45 --> Config Class Initialized
DEBUG - 2013-01-05 07:54:45 --> Hooks Class Initialized
DEBUG - 2013-01-05 07:54:45 --> Utf8 Class Initialized
DEBUG - 2013-01-05 07:54:45 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 07:54:46 --> URI Class Initialized
DEBUG - 2013-01-05 07:54:46 --> Router Class Initialized
DEBUG - 2013-01-05 07:54:46 --> No URI present. Default controller set.
DEBUG - 2013-01-05 07:54:46 --> Output Class Initialized
DEBUG - 2013-01-05 07:54:46 --> Security Class Initialized
DEBUG - 2013-01-05 07:54:46 --> Input Class Initialized
DEBUG - 2013-01-05 07:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 07:54:46 --> Language Class Initialized
DEBUG - 2013-01-05 07:54:46 --> Loader Class Initialized
DEBUG - 2013-01-05 07:54:46 --> Helper loaded: url_helper
DEBUG - 2013-01-05 07:54:46 --> Controller Class Initialized
DEBUG - 2013-01-05 07:54:46 --> Model Class Initialized
DEBUG - 2013-01-05 07:54:46 --> Model Class Initialized
DEBUG - 2013-01-05 07:54:46 --> Database Driver Class Initialized
DEBUG - 2013-01-05 07:54:46 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 07:54:46 --> Final output sent to browser
DEBUG - 2013-01-05 07:54:46 --> Total execution time: 0.3680
DEBUG - 2013-01-05 08:00:27 --> Config Class Initialized
DEBUG - 2013-01-05 08:00:27 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:00:27 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:00:27 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:00:27 --> URI Class Initialized
DEBUG - 2013-01-05 08:00:27 --> Router Class Initialized
DEBUG - 2013-01-05 08:00:27 --> Output Class Initialized
DEBUG - 2013-01-05 08:00:27 --> Security Class Initialized
DEBUG - 2013-01-05 08:00:27 --> Input Class Initialized
DEBUG - 2013-01-05 08:00:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:00:27 --> Language Class Initialized
DEBUG - 2013-01-05 08:00:27 --> Loader Class Initialized
DEBUG - 2013-01-05 08:00:27 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:00:27 --> Controller Class Initialized
DEBUG - 2013-01-05 08:00:27 --> Model Class Initialized
DEBUG - 2013-01-05 08:00:27 --> Model Class Initialized
DEBUG - 2013-01-05 08:00:27 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:00:27 --> 404 Page Not Found --> mobiba_controller/getExcel
DEBUG - 2013-01-05 08:01:23 --> Config Class Initialized
DEBUG - 2013-01-05 08:01:23 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:01:23 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:01:23 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:01:23 --> URI Class Initialized
DEBUG - 2013-01-05 08:01:23 --> Router Class Initialized
DEBUG - 2013-01-05 08:01:23 --> Output Class Initialized
DEBUG - 2013-01-05 08:01:23 --> Security Class Initialized
DEBUG - 2013-01-05 08:01:23 --> Input Class Initialized
DEBUG - 2013-01-05 08:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:01:23 --> Language Class Initialized
DEBUG - 2013-01-05 08:01:23 --> Loader Class Initialized
DEBUG - 2013-01-05 08:01:23 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:01:23 --> Controller Class Initialized
DEBUG - 2013-01-05 08:01:23 --> Model Class Initialized
DEBUG - 2013-01-05 08:01:23 --> Model Class Initialized
DEBUG - 2013-01-05 08:01:23 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:01:23 --> 404 Page Not Found --> mobiba_controller/newRegister
DEBUG - 2013-01-05 08:01:32 --> Config Class Initialized
DEBUG - 2013-01-05 08:01:32 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:01:32 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:01:32 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:01:32 --> URI Class Initialized
DEBUG - 2013-01-05 08:01:32 --> Router Class Initialized
DEBUG - 2013-01-05 08:01:32 --> Output Class Initialized
DEBUG - 2013-01-05 08:01:32 --> Security Class Initialized
DEBUG - 2013-01-05 08:01:32 --> Input Class Initialized
DEBUG - 2013-01-05 08:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:01:32 --> Language Class Initialized
DEBUG - 2013-01-05 08:01:32 --> Loader Class Initialized
DEBUG - 2013-01-05 08:01:32 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:01:32 --> Controller Class Initialized
DEBUG - 2013-01-05 08:01:32 --> Model Class Initialized
DEBUG - 2013-01-05 08:01:32 --> Model Class Initialized
DEBUG - 2013-01-05 08:01:32 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:01:32 --> Severity: Notice  --> Undefined index: email C:\wamp\www\mobiba_service\application\controllers\mobiba_controller.php 38
ERROR - 2013-01-05 08:01:32 --> Severity: Notice  --> Undefined index: password C:\wamp\www\mobiba_service\application\controllers\mobiba_controller.php 39
ERROR - 2013-01-05 08:01:32 --> Severity: Notice  --> Undefined index: balance C:\wamp\www\mobiba_service\application\controllers\mobiba_controller.php 40
ERROR - 2013-01-05 08:01:32 --> Severity: Notice  --> Undefined index: fname C:\wamp\www\mobiba_service\application\controllers\mobiba_controller.php 41
ERROR - 2013-01-05 08:01:32 --> Severity: Notice  --> Undefined index: lname C:\wamp\www\mobiba_service\application\controllers\mobiba_controller.php 42
DEBUG - 2013-01-05 08:01:32 --> Final output sent to browser
DEBUG - 2013-01-05 08:01:32 --> Total execution time: 0.2008
DEBUG - 2013-01-05 08:14:58 --> Config Class Initialized
DEBUG - 2013-01-05 08:14:58 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:14:58 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:14:58 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:14:58 --> URI Class Initialized
DEBUG - 2013-01-05 08:14:58 --> Router Class Initialized
DEBUG - 2013-01-05 08:14:58 --> No URI present. Default controller set.
DEBUG - 2013-01-05 08:14:58 --> Output Class Initialized
DEBUG - 2013-01-05 08:14:58 --> Security Class Initialized
DEBUG - 2013-01-05 08:14:58 --> Input Class Initialized
DEBUG - 2013-01-05 08:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:14:58 --> Language Class Initialized
DEBUG - 2013-01-05 08:14:58 --> Loader Class Initialized
DEBUG - 2013-01-05 08:14:58 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:14:58 --> Controller Class Initialized
DEBUG - 2013-01-05 08:14:58 --> Model Class Initialized
DEBUG - 2013-01-05 08:14:58 --> Model Class Initialized
DEBUG - 2013-01-05 08:14:58 --> Database Driver Class Initialized
DEBUG - 2013-01-05 08:14:58 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 08:14:58 --> Final output sent to browser
DEBUG - 2013-01-05 08:14:58 --> Total execution time: 0.2231
DEBUG - 2013-01-05 08:28:41 --> Config Class Initialized
DEBUG - 2013-01-05 08:28:41 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:28:41 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:28:41 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:28:41 --> URI Class Initialized
DEBUG - 2013-01-05 08:28:41 --> Router Class Initialized
DEBUG - 2013-01-05 08:28:41 --> No URI present. Default controller set.
DEBUG - 2013-01-05 08:28:41 --> Output Class Initialized
DEBUG - 2013-01-05 08:28:41 --> Security Class Initialized
DEBUG - 2013-01-05 08:28:41 --> Input Class Initialized
DEBUG - 2013-01-05 08:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:28:41 --> Language Class Initialized
DEBUG - 2013-01-05 08:28:42 --> Loader Class Initialized
DEBUG - 2013-01-05 08:28:42 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:28:42 --> Controller Class Initialized
DEBUG - 2013-01-05 08:28:42 --> Model Class Initialized
DEBUG - 2013-01-05 08:28:42 --> Model Class Initialized
DEBUG - 2013-01-05 08:28:42 --> Database Driver Class Initialized
DEBUG - 2013-01-05 08:28:42 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 08:28:42 --> Final output sent to browser
DEBUG - 2013-01-05 08:28:42 --> Total execution time: 0.8848
DEBUG - 2013-01-05 08:35:43 --> Config Class Initialized
DEBUG - 2013-01-05 08:35:43 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:35:43 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:35:43 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:35:43 --> URI Class Initialized
DEBUG - 2013-01-05 08:35:43 --> Router Class Initialized
DEBUG - 2013-01-05 08:35:43 --> No URI present. Default controller set.
DEBUG - 2013-01-05 08:35:43 --> Output Class Initialized
DEBUG - 2013-01-05 08:35:43 --> Security Class Initialized
DEBUG - 2013-01-05 08:35:43 --> Input Class Initialized
DEBUG - 2013-01-05 08:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:35:43 --> Language Class Initialized
DEBUG - 2013-01-05 08:35:43 --> Loader Class Initialized
DEBUG - 2013-01-05 08:35:43 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:35:43 --> Controller Class Initialized
DEBUG - 2013-01-05 08:35:43 --> Model Class Initialized
DEBUG - 2013-01-05 08:35:43 --> Model Class Initialized
DEBUG - 2013-01-05 08:35:43 --> Database Driver Class Initialized
DEBUG - 2013-01-05 08:35:43 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 08:35:43 --> Final output sent to browser
DEBUG - 2013-01-05 08:35:43 --> Total execution time: 0.2249
DEBUG - 2013-01-05 08:41:09 --> Config Class Initialized
DEBUG - 2013-01-05 08:41:09 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:41:09 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:41:09 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:41:09 --> URI Class Initialized
DEBUG - 2013-01-05 08:41:09 --> Router Class Initialized
DEBUG - 2013-01-05 08:41:09 --> No URI present. Default controller set.
DEBUG - 2013-01-05 08:41:09 --> Output Class Initialized
DEBUG - 2013-01-05 08:41:09 --> Security Class Initialized
DEBUG - 2013-01-05 08:41:09 --> Input Class Initialized
DEBUG - 2013-01-05 08:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:41:09 --> Language Class Initialized
DEBUG - 2013-01-05 08:41:09 --> Loader Class Initialized
DEBUG - 2013-01-05 08:41:09 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:41:09 --> Controller Class Initialized
DEBUG - 2013-01-05 08:41:09 --> Model Class Initialized
DEBUG - 2013-01-05 08:41:09 --> Model Class Initialized
DEBUG - 2013-01-05 08:41:09 --> Database Driver Class Initialized
DEBUG - 2013-01-05 08:41:09 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 08:41:09 --> Final output sent to browser
DEBUG - 2013-01-05 08:41:09 --> Total execution time: 0.1833
DEBUG - 2013-01-05 08:41:29 --> Config Class Initialized
DEBUG - 2013-01-05 08:41:29 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:41:29 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:41:29 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:41:29 --> URI Class Initialized
DEBUG - 2013-01-05 08:41:29 --> Router Class Initialized
DEBUG - 2013-01-05 08:41:29 --> No URI present. Default controller set.
DEBUG - 2013-01-05 08:41:29 --> Output Class Initialized
DEBUG - 2013-01-05 08:41:29 --> Security Class Initialized
DEBUG - 2013-01-05 08:41:29 --> Input Class Initialized
DEBUG - 2013-01-05 08:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:41:29 --> Language Class Initialized
DEBUG - 2013-01-05 08:41:29 --> Loader Class Initialized
DEBUG - 2013-01-05 08:41:29 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:41:29 --> Controller Class Initialized
DEBUG - 2013-01-05 08:41:29 --> Model Class Initialized
DEBUG - 2013-01-05 08:41:29 --> Model Class Initialized
DEBUG - 2013-01-05 08:41:29 --> Database Driver Class Initialized
DEBUG - 2013-01-05 08:41:29 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 08:41:29 --> Final output sent to browser
DEBUG - 2013-01-05 08:41:29 --> Total execution time: 0.1775
DEBUG - 2013-01-05 08:43:21 --> Config Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:43:21 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:43:21 --> URI Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Router Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Output Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Security Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Input Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:43:21 --> Language Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Loader Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:43:21 --> Controller Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Model Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Model Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Database Driver Class Initialized
DEBUG - 2013-01-05 08:43:21 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-05 08:43:21 --> Final output sent to browser
DEBUG - 2013-01-05 08:43:21 --> Total execution time: 0.1966
DEBUG - 2013-01-05 08:43:21 --> Config Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:43:21 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:43:21 --> URI Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Router Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Output Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Security Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Input Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:43:21 --> Language Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Loader Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:43:21 --> Controller Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Model Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Model Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:43:21 --> 404 Page Not Found --> mobiba_controller/js
DEBUG - 2013-01-05 08:43:21 --> Config Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:43:21 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:43:21 --> URI Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Router Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Output Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Security Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Input Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:43:21 --> Language Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Loader Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:43:21 --> Controller Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Model Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Model Class Initialized
DEBUG - 2013-01-05 08:43:21 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:43:21 --> 404 Page Not Found --> mobiba_controller/getExcel
DEBUG - 2013-01-05 08:44:15 --> Config Class Initialized
DEBUG - 2013-01-05 08:44:15 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:44:15 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:44:15 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:44:15 --> URI Class Initialized
DEBUG - 2013-01-05 08:44:15 --> Router Class Initialized
DEBUG - 2013-01-05 08:44:15 --> Output Class Initialized
DEBUG - 2013-01-05 08:44:15 --> Security Class Initialized
DEBUG - 2013-01-05 08:44:15 --> Input Class Initialized
DEBUG - 2013-01-05 08:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:44:15 --> Language Class Initialized
DEBUG - 2013-01-05 08:44:15 --> Loader Class Initialized
DEBUG - 2013-01-05 08:44:15 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:44:15 --> Controller Class Initialized
DEBUG - 2013-01-05 08:44:15 --> Model Class Initialized
DEBUG - 2013-01-05 08:44:15 --> Model Class Initialized
DEBUG - 2013-01-05 08:44:15 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:44:15 --> Severity: Notice  --> Undefined index: email C:\wamp\www\mobiba_service\application\controllers\mobiba_controller.php 38
ERROR - 2013-01-05 08:44:15 --> Severity: Notice  --> Undefined index: password C:\wamp\www\mobiba_service\application\controllers\mobiba_controller.php 39
ERROR - 2013-01-05 08:44:15 --> Severity: Notice  --> Undefined index: balance C:\wamp\www\mobiba_service\application\controllers\mobiba_controller.php 40
ERROR - 2013-01-05 08:44:15 --> Severity: Notice  --> Undefined index: fname C:\wamp\www\mobiba_service\application\controllers\mobiba_controller.php 41
ERROR - 2013-01-05 08:44:15 --> Severity: Notice  --> Undefined index: lname C:\wamp\www\mobiba_service\application\controllers\mobiba_controller.php 42
DEBUG - 2013-01-05 08:44:15 --> Final output sent to browser
DEBUG - 2013-01-05 08:44:15 --> Total execution time: 0.1958
DEBUG - 2013-01-05 08:44:21 --> Config Class Initialized
DEBUG - 2013-01-05 08:44:21 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:44:21 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:44:21 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:44:21 --> URI Class Initialized
DEBUG - 2013-01-05 08:44:21 --> Router Class Initialized
DEBUG - 2013-01-05 08:44:21 --> Output Class Initialized
DEBUG - 2013-01-05 08:44:21 --> Security Class Initialized
DEBUG - 2013-01-05 08:44:21 --> Input Class Initialized
DEBUG - 2013-01-05 08:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:44:21 --> Language Class Initialized
DEBUG - 2013-01-05 08:44:21 --> Loader Class Initialized
DEBUG - 2013-01-05 08:44:21 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:44:21 --> Controller Class Initialized
DEBUG - 2013-01-05 08:44:21 --> Model Class Initialized
DEBUG - 2013-01-05 08:44:21 --> Model Class Initialized
DEBUG - 2013-01-05 08:44:21 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:44:21 --> 404 Page Not Found --> mobiba_controller/newregister
DEBUG - 2013-01-05 08:44:26 --> Config Class Initialized
DEBUG - 2013-01-05 08:44:26 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:44:26 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:44:26 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:44:26 --> URI Class Initialized
DEBUG - 2013-01-05 08:44:26 --> Router Class Initialized
DEBUG - 2013-01-05 08:44:26 --> Output Class Initialized
DEBUG - 2013-01-05 08:44:26 --> Security Class Initialized
DEBUG - 2013-01-05 08:44:26 --> Input Class Initialized
DEBUG - 2013-01-05 08:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:44:26 --> Language Class Initialized
DEBUG - 2013-01-05 08:44:26 --> Loader Class Initialized
DEBUG - 2013-01-05 08:44:26 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:44:26 --> Controller Class Initialized
DEBUG - 2013-01-05 08:44:26 --> Model Class Initialized
DEBUG - 2013-01-05 08:44:26 --> Model Class Initialized
DEBUG - 2013-01-05 08:44:26 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:44:26 --> 404 Page Not Found --> mobiba_controller/new_register
DEBUG - 2013-01-05 08:44:32 --> Config Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:44:32 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:44:32 --> URI Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Router Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Output Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Security Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Input Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:44:32 --> Language Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Loader Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:44:32 --> Controller Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Model Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Model Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Database Driver Class Initialized
DEBUG - 2013-01-05 08:44:32 --> File loaded: application/views/register.php
DEBUG - 2013-01-05 08:44:32 --> Final output sent to browser
DEBUG - 2013-01-05 08:44:32 --> Total execution time: 0.2395
DEBUG - 2013-01-05 08:44:32 --> Config Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:44:32 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:44:32 --> URI Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Router Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Output Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Security Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Input Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:44:32 --> Language Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Loader Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:44:32 --> Controller Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Model Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Model Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:44:32 --> 404 Page Not Found --> mobiba_controller/js
DEBUG - 2013-01-05 08:44:32 --> Config Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:44:32 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:44:32 --> URI Class Initialized
DEBUG - 2013-01-05 08:44:32 --> Router Class Initialized
DEBUG - 2013-01-05 08:44:33 --> Output Class Initialized
DEBUG - 2013-01-05 08:44:33 --> Security Class Initialized
DEBUG - 2013-01-05 08:44:33 --> Input Class Initialized
DEBUG - 2013-01-05 08:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:44:33 --> Language Class Initialized
DEBUG - 2013-01-05 08:44:33 --> Loader Class Initialized
DEBUG - 2013-01-05 08:44:33 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:44:33 --> Controller Class Initialized
DEBUG - 2013-01-05 08:44:33 --> Model Class Initialized
DEBUG - 2013-01-05 08:44:33 --> Model Class Initialized
DEBUG - 2013-01-05 08:44:33 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:44:33 --> 404 Page Not Found --> mobiba_controller/getExcel
DEBUG - 2013-01-05 08:45:24 --> Config Class Initialized
DEBUG - 2013-01-05 08:45:24 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:45:24 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:45:24 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:45:24 --> URI Class Initialized
DEBUG - 2013-01-05 08:45:24 --> Router Class Initialized
DEBUG - 2013-01-05 08:45:24 --> No URI present. Default controller set.
DEBUG - 2013-01-05 08:45:24 --> Output Class Initialized
DEBUG - 2013-01-05 08:45:24 --> Security Class Initialized
DEBUG - 2013-01-05 08:45:24 --> Input Class Initialized
DEBUG - 2013-01-05 08:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:45:24 --> Language Class Initialized
DEBUG - 2013-01-05 08:45:24 --> Loader Class Initialized
DEBUG - 2013-01-05 08:45:24 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:45:24 --> Controller Class Initialized
DEBUG - 2013-01-05 08:45:24 --> Model Class Initialized
DEBUG - 2013-01-05 08:45:24 --> Model Class Initialized
DEBUG - 2013-01-05 08:45:24 --> Database Driver Class Initialized
DEBUG - 2013-01-05 08:45:24 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 08:45:24 --> Final output sent to browser
DEBUG - 2013-01-05 08:45:24 --> Total execution time: 0.2103
DEBUG - 2013-01-05 08:45:59 --> Config Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:45:59 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:45:59 --> URI Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Router Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Output Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Security Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Input Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:45:59 --> Language Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Loader Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:45:59 --> Controller Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Model Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Model Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Database Driver Class Initialized
DEBUG - 2013-01-05 08:45:59 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-05 08:45:59 --> Final output sent to browser
DEBUG - 2013-01-05 08:45:59 --> Total execution time: 0.1948
DEBUG - 2013-01-05 08:45:59 --> Config Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:45:59 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:45:59 --> URI Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Router Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Output Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Security Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Input Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:45:59 --> Language Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Loader Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:45:59 --> Controller Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Model Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Model Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:45:59 --> 404 Page Not Found --> mobiba_controller/js
DEBUG - 2013-01-05 08:45:59 --> Config Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:45:59 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:45:59 --> URI Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Router Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Output Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Security Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Input Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:45:59 --> Language Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Loader Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:45:59 --> Controller Class Initialized
DEBUG - 2013-01-05 08:45:59 --> Model Class Initialized
DEBUG - 2013-01-05 08:46:00 --> Model Class Initialized
DEBUG - 2013-01-05 08:46:00 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:46:00 --> 404 Page Not Found --> mobiba_controller/getExcel
DEBUG - 2013-01-05 08:48:13 --> Config Class Initialized
DEBUG - 2013-01-05 08:48:13 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:48:13 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:48:13 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:48:13 --> URI Class Initialized
DEBUG - 2013-01-05 08:48:13 --> Router Class Initialized
DEBUG - 2013-01-05 08:48:13 --> No URI present. Default controller set.
DEBUG - 2013-01-05 08:48:13 --> Output Class Initialized
DEBUG - 2013-01-05 08:48:13 --> Security Class Initialized
DEBUG - 2013-01-05 08:48:13 --> Input Class Initialized
DEBUG - 2013-01-05 08:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:48:13 --> Language Class Initialized
DEBUG - 2013-01-05 08:48:13 --> Loader Class Initialized
DEBUG - 2013-01-05 08:48:13 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:48:13 --> Controller Class Initialized
DEBUG - 2013-01-05 08:48:13 --> Model Class Initialized
DEBUG - 2013-01-05 08:48:13 --> Model Class Initialized
DEBUG - 2013-01-05 08:48:13 --> Database Driver Class Initialized
DEBUG - 2013-01-05 08:48:13 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 08:48:13 --> Final output sent to browser
DEBUG - 2013-01-05 08:48:13 --> Total execution time: 0.1856
DEBUG - 2013-01-05 08:48:16 --> Config Class Initialized
DEBUG - 2013-01-05 08:48:16 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:48:16 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:48:16 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:48:16 --> URI Class Initialized
DEBUG - 2013-01-05 08:48:16 --> Router Class Initialized
DEBUG - 2013-01-05 08:48:16 --> Output Class Initialized
DEBUG - 2013-01-05 08:48:16 --> Security Class Initialized
DEBUG - 2013-01-05 08:48:16 --> Input Class Initialized
DEBUG - 2013-01-05 08:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:48:16 --> Language Class Initialized
DEBUG - 2013-01-05 08:48:16 --> Loader Class Initialized
DEBUG - 2013-01-05 08:48:16 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:48:16 --> Controller Class Initialized
DEBUG - 2013-01-05 08:48:16 --> Model Class Initialized
DEBUG - 2013-01-05 08:48:16 --> Model Class Initialized
DEBUG - 2013-01-05 08:48:16 --> Database Driver Class Initialized
DEBUG - 2013-01-05 08:48:16 --> File loaded: application/views/register.php
DEBUG - 2013-01-05 08:48:16 --> Final output sent to browser
DEBUG - 2013-01-05 08:48:16 --> Total execution time: 0.1943
DEBUG - 2013-01-05 08:48:16 --> Config Class Initialized
DEBUG - 2013-01-05 08:48:16 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:48:17 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:48:17 --> URI Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Router Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Output Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Security Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Input Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:48:17 --> Language Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Loader Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:48:17 --> Controller Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Model Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Model Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:48:17 --> 404 Page Not Found --> mobiba_controller/js
DEBUG - 2013-01-05 08:48:17 --> Config Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:48:17 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:48:17 --> URI Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Router Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Output Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Security Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Input Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:48:17 --> Language Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Loader Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:48:17 --> Controller Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Model Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Model Class Initialized
DEBUG - 2013-01-05 08:48:17 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:48:17 --> 404 Page Not Found --> mobiba_controller/getExcel
DEBUG - 2013-01-05 08:50:39 --> Config Class Initialized
DEBUG - 2013-01-05 08:50:39 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:50:39 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:50:39 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:50:39 --> URI Class Initialized
DEBUG - 2013-01-05 08:50:39 --> Router Class Initialized
DEBUG - 2013-01-05 08:50:39 --> No URI present. Default controller set.
DEBUG - 2013-01-05 08:50:39 --> Output Class Initialized
DEBUG - 2013-01-05 08:50:39 --> Security Class Initialized
DEBUG - 2013-01-05 08:50:39 --> Input Class Initialized
DEBUG - 2013-01-05 08:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:50:39 --> Language Class Initialized
DEBUG - 2013-01-05 08:50:39 --> Loader Class Initialized
DEBUG - 2013-01-05 08:50:39 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:50:39 --> Controller Class Initialized
DEBUG - 2013-01-05 08:50:39 --> Model Class Initialized
DEBUG - 2013-01-05 08:50:39 --> Model Class Initialized
DEBUG - 2013-01-05 08:50:39 --> Database Driver Class Initialized
DEBUG - 2013-01-05 08:50:39 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 08:50:39 --> Final output sent to browser
DEBUG - 2013-01-05 08:50:39 --> Total execution time: 0.1851
DEBUG - 2013-01-05 08:50:41 --> Config Class Initialized
DEBUG - 2013-01-05 08:50:41 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:50:41 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:50:41 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:50:42 --> URI Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Router Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Output Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Security Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Input Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:50:42 --> Language Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Loader Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:50:42 --> Controller Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Model Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Model Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Database Driver Class Initialized
DEBUG - 2013-01-05 08:50:42 --> File loaded: application/views/register.php
DEBUG - 2013-01-05 08:50:42 --> Final output sent to browser
DEBUG - 2013-01-05 08:50:42 --> Total execution time: 0.1842
DEBUG - 2013-01-05 08:50:42 --> Config Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:50:42 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:50:42 --> URI Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Router Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Output Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Security Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Input Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:50:42 --> Language Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Loader Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:50:42 --> Controller Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Model Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Model Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:50:42 --> 404 Page Not Found --> mobiba_controller/js
DEBUG - 2013-01-05 08:50:42 --> Config Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:50:42 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:50:42 --> URI Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Router Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Output Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Security Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Input Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:50:42 --> Language Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Loader Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:50:42 --> Controller Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Model Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Model Class Initialized
DEBUG - 2013-01-05 08:50:42 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:50:42 --> 404 Page Not Found --> mobiba_controller/getExcel
DEBUG - 2013-01-05 08:50:59 --> Config Class Initialized
DEBUG - 2013-01-05 08:50:59 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:50:59 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:50:59 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:50:59 --> URI Class Initialized
DEBUG - 2013-01-05 08:50:59 --> Router Class Initialized
DEBUG - 2013-01-05 08:50:59 --> Output Class Initialized
DEBUG - 2013-01-05 08:50:59 --> Security Class Initialized
DEBUG - 2013-01-05 08:50:59 --> Input Class Initialized
DEBUG - 2013-01-05 08:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:50:59 --> Language Class Initialized
DEBUG - 2013-01-05 08:50:59 --> Loader Class Initialized
DEBUG - 2013-01-05 08:50:59 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:50:59 --> Controller Class Initialized
DEBUG - 2013-01-05 08:50:59 --> Model Class Initialized
DEBUG - 2013-01-05 08:50:59 --> Model Class Initialized
DEBUG - 2013-01-05 08:50:59 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:50:59 --> 404 Page Not Found --> mobiba_controller/index.php
DEBUG - 2013-01-05 08:51:44 --> Config Class Initialized
DEBUG - 2013-01-05 08:51:44 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:51:44 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:51:44 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:51:44 --> URI Class Initialized
DEBUG - 2013-01-05 08:51:44 --> Router Class Initialized
DEBUG - 2013-01-05 08:51:44 --> Output Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Security Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Input Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:51:45 --> Language Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Loader Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:51:45 --> Controller Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Model Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Model Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:51:45 --> 404 Page Not Found --> mobiba_controller/js
DEBUG - 2013-01-05 08:51:45 --> Config Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:51:45 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:51:45 --> URI Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Router Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Output Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Security Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Input Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:51:45 --> Language Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Loader Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:51:45 --> Controller Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Model Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Model Class Initialized
DEBUG - 2013-01-05 08:51:45 --> Database Driver Class Initialized
ERROR - 2013-01-05 08:51:45 --> 404 Page Not Found --> mobiba_controller/getExcel
DEBUG - 2013-01-05 08:53:42 --> Config Class Initialized
DEBUG - 2013-01-05 08:53:42 --> Hooks Class Initialized
DEBUG - 2013-01-05 08:53:42 --> Utf8 Class Initialized
DEBUG - 2013-01-05 08:53:42 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 08:53:42 --> URI Class Initialized
DEBUG - 2013-01-05 08:53:42 --> Router Class Initialized
DEBUG - 2013-01-05 08:53:42 --> No URI present. Default controller set.
DEBUG - 2013-01-05 08:53:42 --> Output Class Initialized
DEBUG - 2013-01-05 08:53:42 --> Security Class Initialized
DEBUG - 2013-01-05 08:53:42 --> Input Class Initialized
DEBUG - 2013-01-05 08:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 08:53:42 --> Language Class Initialized
DEBUG - 2013-01-05 08:53:42 --> Loader Class Initialized
DEBUG - 2013-01-05 08:53:42 --> Helper loaded: url_helper
DEBUG - 2013-01-05 08:53:42 --> Controller Class Initialized
DEBUG - 2013-01-05 08:53:42 --> Model Class Initialized
DEBUG - 2013-01-05 08:53:42 --> Model Class Initialized
DEBUG - 2013-01-05 08:53:42 --> Database Driver Class Initialized
DEBUG - 2013-01-05 08:53:42 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 08:53:42 --> Final output sent to browser
DEBUG - 2013-01-05 08:53:42 --> Total execution time: 0.2434
DEBUG - 2013-01-05 09:15:19 --> Config Class Initialized
DEBUG - 2013-01-05 09:15:19 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:15:19 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:15:19 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:15:19 --> URI Class Initialized
DEBUG - 2013-01-05 09:15:19 --> Router Class Initialized
DEBUG - 2013-01-05 09:15:19 --> No URI present. Default controller set.
DEBUG - 2013-01-05 09:15:19 --> Output Class Initialized
DEBUG - 2013-01-05 09:15:19 --> Security Class Initialized
DEBUG - 2013-01-05 09:15:19 --> Input Class Initialized
DEBUG - 2013-01-05 09:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 09:15:19 --> Language Class Initialized
DEBUG - 2013-01-05 09:15:19 --> Loader Class Initialized
DEBUG - 2013-01-05 09:15:19 --> Helper loaded: url_helper
DEBUG - 2013-01-05 09:15:19 --> Controller Class Initialized
DEBUG - 2013-01-05 09:15:19 --> Model Class Initialized
DEBUG - 2013-01-05 09:15:19 --> Model Class Initialized
DEBUG - 2013-01-05 09:15:19 --> Database Driver Class Initialized
DEBUG - 2013-01-05 09:15:19 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 09:15:19 --> Final output sent to browser
DEBUG - 2013-01-05 09:15:19 --> Total execution time: 0.1918
DEBUG - 2013-01-05 09:17:22 --> Config Class Initialized
DEBUG - 2013-01-05 09:17:22 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:17:22 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:17:22 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:17:22 --> URI Class Initialized
DEBUG - 2013-01-05 09:17:22 --> Router Class Initialized
DEBUG - 2013-01-05 09:17:22 --> No URI present. Default controller set.
DEBUG - 2013-01-05 09:17:22 --> Output Class Initialized
DEBUG - 2013-01-05 09:17:22 --> Security Class Initialized
DEBUG - 2013-01-05 09:17:22 --> Input Class Initialized
DEBUG - 2013-01-05 09:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 09:17:22 --> Language Class Initialized
DEBUG - 2013-01-05 09:17:22 --> Loader Class Initialized
DEBUG - 2013-01-05 09:17:22 --> Helper loaded: url_helper
DEBUG - 2013-01-05 09:17:22 --> Controller Class Initialized
DEBUG - 2013-01-05 09:17:22 --> Model Class Initialized
DEBUG - 2013-01-05 09:17:22 --> Model Class Initialized
DEBUG - 2013-01-05 09:17:22 --> Database Driver Class Initialized
DEBUG - 2013-01-05 09:17:23 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 09:17:23 --> Final output sent to browser
DEBUG - 2013-01-05 09:17:23 --> Total execution time: 0.8583
DEBUG - 2013-01-05 09:17:24 --> Config Class Initialized
DEBUG - 2013-01-05 09:17:24 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:17:24 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:17:24 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:17:24 --> URI Class Initialized
DEBUG - 2013-01-05 09:17:24 --> Router Class Initialized
DEBUG - 2013-01-05 09:17:24 --> Output Class Initialized
DEBUG - 2013-01-05 09:17:24 --> Security Class Initialized
DEBUG - 2013-01-05 09:17:24 --> Input Class Initialized
DEBUG - 2013-01-05 09:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 09:17:24 --> Language Class Initialized
DEBUG - 2013-01-05 09:17:24 --> Loader Class Initialized
DEBUG - 2013-01-05 09:17:24 --> Helper loaded: url_helper
DEBUG - 2013-01-05 09:17:24 --> Controller Class Initialized
DEBUG - 2013-01-05 09:17:24 --> Model Class Initialized
DEBUG - 2013-01-05 09:17:24 --> Model Class Initialized
DEBUG - 2013-01-05 09:17:24 --> Database Driver Class Initialized
DEBUG - 2013-01-05 09:17:24 --> File loaded: application/views/register.php
DEBUG - 2013-01-05 09:17:24 --> Final output sent to browser
DEBUG - 2013-01-05 09:17:24 --> Total execution time: 0.1987
DEBUG - 2013-01-05 09:17:24 --> Config Class Initialized
DEBUG - 2013-01-05 09:17:24 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:17:25 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:17:25 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:17:25 --> URI Class Initialized
DEBUG - 2013-01-05 09:17:25 --> Router Class Initialized
ERROR - 2013-01-05 09:17:25 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-05 09:17:44 --> Config Class Initialized
DEBUG - 2013-01-05 09:17:44 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:17:44 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:17:44 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:17:44 --> URI Class Initialized
DEBUG - 2013-01-05 09:17:44 --> Router Class Initialized
DEBUG - 2013-01-05 09:17:44 --> Output Class Initialized
DEBUG - 2013-01-05 09:17:44 --> Security Class Initialized
DEBUG - 2013-01-05 09:17:44 --> Input Class Initialized
DEBUG - 2013-01-05 09:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 09:17:44 --> Language Class Initialized
DEBUG - 2013-01-05 09:17:44 --> Loader Class Initialized
DEBUG - 2013-01-05 09:17:44 --> Helper loaded: url_helper
DEBUG - 2013-01-05 09:17:44 --> Controller Class Initialized
DEBUG - 2013-01-05 09:17:44 --> Model Class Initialized
DEBUG - 2013-01-05 09:17:44 --> Model Class Initialized
DEBUG - 2013-01-05 09:17:44 --> Database Driver Class Initialized
DEBUG - 2013-01-05 09:17:44 --> Final output sent to browser
DEBUG - 2013-01-05 09:17:44 --> Total execution time: 0.4704
DEBUG - 2013-01-05 09:18:32 --> Config Class Initialized
DEBUG - 2013-01-05 09:18:32 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:18:32 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:18:32 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:18:32 --> URI Class Initialized
DEBUG - 2013-01-05 09:18:32 --> Router Class Initialized
DEBUG - 2013-01-05 09:18:32 --> No URI present. Default controller set.
DEBUG - 2013-01-05 09:18:32 --> Output Class Initialized
DEBUG - 2013-01-05 09:18:32 --> Security Class Initialized
DEBUG - 2013-01-05 09:18:32 --> Input Class Initialized
DEBUG - 2013-01-05 09:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 09:18:32 --> Language Class Initialized
DEBUG - 2013-01-05 09:18:32 --> Loader Class Initialized
DEBUG - 2013-01-05 09:18:32 --> Helper loaded: url_helper
DEBUG - 2013-01-05 09:18:32 --> Controller Class Initialized
DEBUG - 2013-01-05 09:18:32 --> Model Class Initialized
DEBUG - 2013-01-05 09:18:32 --> Model Class Initialized
DEBUG - 2013-01-05 09:18:32 --> Database Driver Class Initialized
DEBUG - 2013-01-05 09:18:32 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 09:18:32 --> Final output sent to browser
DEBUG - 2013-01-05 09:18:32 --> Total execution time: 0.1926
DEBUG - 2013-01-05 09:18:35 --> Config Class Initialized
DEBUG - 2013-01-05 09:18:35 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:18:35 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:18:35 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:18:35 --> URI Class Initialized
DEBUG - 2013-01-05 09:18:35 --> Router Class Initialized
DEBUG - 2013-01-05 09:18:35 --> Output Class Initialized
DEBUG - 2013-01-05 09:18:35 --> Security Class Initialized
DEBUG - 2013-01-05 09:18:35 --> Input Class Initialized
DEBUG - 2013-01-05 09:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 09:18:35 --> Language Class Initialized
DEBUG - 2013-01-05 09:18:35 --> Loader Class Initialized
DEBUG - 2013-01-05 09:18:35 --> Helper loaded: url_helper
DEBUG - 2013-01-05 09:18:35 --> Controller Class Initialized
DEBUG - 2013-01-05 09:18:35 --> Model Class Initialized
DEBUG - 2013-01-05 09:18:35 --> Model Class Initialized
DEBUG - 2013-01-05 09:18:35 --> Database Driver Class Initialized
DEBUG - 2013-01-05 09:18:35 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-05 09:18:35 --> Final output sent to browser
DEBUG - 2013-01-05 09:18:35 --> Total execution time: 0.1959
DEBUG - 2013-01-05 09:18:35 --> Config Class Initialized
DEBUG - 2013-01-05 09:18:35 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:18:35 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:18:35 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:18:35 --> URI Class Initialized
DEBUG - 2013-01-05 09:18:35 --> Router Class Initialized
ERROR - 2013-01-05 09:18:35 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-05 09:18:43 --> Config Class Initialized
DEBUG - 2013-01-05 09:18:43 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:18:43 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:18:43 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:18:43 --> URI Class Initialized
DEBUG - 2013-01-05 09:18:43 --> Router Class Initialized
DEBUG - 2013-01-05 09:18:43 --> Output Class Initialized
DEBUG - 2013-01-05 09:18:43 --> Security Class Initialized
DEBUG - 2013-01-05 09:18:43 --> Input Class Initialized
DEBUG - 2013-01-05 09:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 09:18:43 --> Language Class Initialized
DEBUG - 2013-01-05 09:18:43 --> Loader Class Initialized
DEBUG - 2013-01-05 09:18:43 --> Helper loaded: url_helper
DEBUG - 2013-01-05 09:18:43 --> Controller Class Initialized
DEBUG - 2013-01-05 09:18:43 --> Model Class Initialized
DEBUG - 2013-01-05 09:18:43 --> Model Class Initialized
DEBUG - 2013-01-05 09:18:43 --> Database Driver Class Initialized
DEBUG - 2013-01-05 09:18:43 --> Final output sent to browser
DEBUG - 2013-01-05 09:18:43 --> Total execution time: 0.3481
DEBUG - 2013-01-05 09:18:56 --> Config Class Initialized
DEBUG - 2013-01-05 09:18:56 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:18:56 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:18:56 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:18:56 --> URI Class Initialized
DEBUG - 2013-01-05 09:18:56 --> Router Class Initialized
DEBUG - 2013-01-05 09:18:56 --> No URI present. Default controller set.
DEBUG - 2013-01-05 09:18:56 --> Output Class Initialized
DEBUG - 2013-01-05 09:18:56 --> Security Class Initialized
DEBUG - 2013-01-05 09:18:56 --> Input Class Initialized
DEBUG - 2013-01-05 09:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 09:18:56 --> Language Class Initialized
DEBUG - 2013-01-05 09:18:56 --> Loader Class Initialized
DEBUG - 2013-01-05 09:18:56 --> Helper loaded: url_helper
DEBUG - 2013-01-05 09:18:56 --> Controller Class Initialized
DEBUG - 2013-01-05 09:18:56 --> Model Class Initialized
DEBUG - 2013-01-05 09:18:56 --> Model Class Initialized
DEBUG - 2013-01-05 09:18:56 --> Database Driver Class Initialized
DEBUG - 2013-01-05 09:18:56 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 09:18:56 --> Final output sent to browser
DEBUG - 2013-01-05 09:18:56 --> Total execution time: 0.1961
DEBUG - 2013-01-05 09:41:09 --> Config Class Initialized
DEBUG - 2013-01-05 09:41:09 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:41:09 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:41:09 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:41:09 --> URI Class Initialized
DEBUG - 2013-01-05 09:41:09 --> Router Class Initialized
DEBUG - 2013-01-05 09:41:09 --> No URI present. Default controller set.
DEBUG - 2013-01-05 09:41:09 --> Output Class Initialized
DEBUG - 2013-01-05 09:41:09 --> Security Class Initialized
DEBUG - 2013-01-05 09:41:09 --> Input Class Initialized
DEBUG - 2013-01-05 09:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 09:41:09 --> Language Class Initialized
DEBUG - 2013-01-05 09:41:09 --> Loader Class Initialized
DEBUG - 2013-01-05 09:41:09 --> Helper loaded: url_helper
DEBUG - 2013-01-05 09:41:09 --> Controller Class Initialized
DEBUG - 2013-01-05 09:41:09 --> Model Class Initialized
DEBUG - 2013-01-05 09:41:09 --> Model Class Initialized
DEBUG - 2013-01-05 09:41:10 --> Database Driver Class Initialized
DEBUG - 2013-01-05 09:41:10 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 09:41:10 --> Final output sent to browser
DEBUG - 2013-01-05 09:41:10 --> Total execution time: 0.2354
DEBUG - 2013-01-05 09:41:11 --> Config Class Initialized
DEBUG - 2013-01-05 09:41:11 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:41:11 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:41:11 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:41:11 --> URI Class Initialized
DEBUG - 2013-01-05 09:41:11 --> Router Class Initialized
DEBUG - 2013-01-05 09:41:11 --> Output Class Initialized
DEBUG - 2013-01-05 09:41:11 --> Security Class Initialized
DEBUG - 2013-01-05 09:41:11 --> Input Class Initialized
DEBUG - 2013-01-05 09:41:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 09:41:11 --> Language Class Initialized
DEBUG - 2013-01-05 09:41:11 --> Loader Class Initialized
DEBUG - 2013-01-05 09:41:11 --> Helper loaded: url_helper
DEBUG - 2013-01-05 09:41:11 --> Controller Class Initialized
DEBUG - 2013-01-05 09:41:11 --> Model Class Initialized
DEBUG - 2013-01-05 09:41:11 --> Model Class Initialized
DEBUG - 2013-01-05 09:41:11 --> Database Driver Class Initialized
DEBUG - 2013-01-05 09:41:11 --> File loaded: application/views/register.php
DEBUG - 2013-01-05 09:41:11 --> Final output sent to browser
DEBUG - 2013-01-05 09:41:11 --> Total execution time: 0.2256
DEBUG - 2013-01-05 09:41:11 --> Config Class Initialized
DEBUG - 2013-01-05 09:41:11 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:41:11 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:41:11 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:41:11 --> URI Class Initialized
DEBUG - 2013-01-05 09:41:11 --> Router Class Initialized
ERROR - 2013-01-05 09:41:11 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-05 09:41:14 --> Config Class Initialized
DEBUG - 2013-01-05 09:41:14 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:41:14 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:41:14 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:41:14 --> URI Class Initialized
DEBUG - 2013-01-05 09:41:14 --> Router Class Initialized
DEBUG - 2013-01-05 09:41:14 --> Output Class Initialized
DEBUG - 2013-01-05 09:41:14 --> Security Class Initialized
DEBUG - 2013-01-05 09:41:14 --> Input Class Initialized
DEBUG - 2013-01-05 09:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 09:41:14 --> Language Class Initialized
DEBUG - 2013-01-05 09:41:14 --> Loader Class Initialized
DEBUG - 2013-01-05 09:41:14 --> Helper loaded: url_helper
DEBUG - 2013-01-05 09:41:14 --> Controller Class Initialized
DEBUG - 2013-01-05 09:41:14 --> Model Class Initialized
DEBUG - 2013-01-05 09:41:14 --> Model Class Initialized
DEBUG - 2013-01-05 09:41:14 --> Database Driver Class Initialized
DEBUG - 2013-01-05 09:41:14 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-05 09:41:14 --> Final output sent to browser
DEBUG - 2013-01-05 09:41:14 --> Total execution time: 0.2249
DEBUG - 2013-01-05 09:41:14 --> Config Class Initialized
DEBUG - 2013-01-05 09:41:14 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:41:14 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:41:14 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:41:14 --> URI Class Initialized
DEBUG - 2013-01-05 09:41:14 --> Router Class Initialized
ERROR - 2013-01-05 09:41:14 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-05 09:41:20 --> Config Class Initialized
DEBUG - 2013-01-05 09:41:20 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:41:20 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:41:20 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:41:20 --> URI Class Initialized
DEBUG - 2013-01-05 09:41:20 --> Router Class Initialized
DEBUG - 2013-01-05 09:41:20 --> Output Class Initialized
DEBUG - 2013-01-05 09:41:20 --> Security Class Initialized
DEBUG - 2013-01-05 09:41:20 --> Input Class Initialized
DEBUG - 2013-01-05 09:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 09:41:20 --> Language Class Initialized
DEBUG - 2013-01-05 09:41:20 --> Loader Class Initialized
DEBUG - 2013-01-05 09:41:20 --> Helper loaded: url_helper
DEBUG - 2013-01-05 09:41:20 --> Controller Class Initialized
DEBUG - 2013-01-05 09:41:20 --> Model Class Initialized
DEBUG - 2013-01-05 09:41:20 --> Model Class Initialized
DEBUG - 2013-01-05 09:41:20 --> Database Driver Class Initialized
DEBUG - 2013-01-05 09:41:20 --> File loaded: application/views/register.php
DEBUG - 2013-01-05 09:41:20 --> Final output sent to browser
DEBUG - 2013-01-05 09:41:20 --> Total execution time: 0.2046
DEBUG - 2013-01-05 09:41:20 --> Config Class Initialized
DEBUG - 2013-01-05 09:41:20 --> Hooks Class Initialized
DEBUG - 2013-01-05 09:41:20 --> Utf8 Class Initialized
DEBUG - 2013-01-05 09:41:20 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 09:41:20 --> URI Class Initialized
DEBUG - 2013-01-05 09:41:20 --> Router Class Initialized
ERROR - 2013-01-05 09:41:20 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-05 10:02:29 --> Config Class Initialized
DEBUG - 2013-01-05 10:02:29 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:02:29 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:02:29 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:02:29 --> URI Class Initialized
DEBUG - 2013-01-05 10:02:29 --> Router Class Initialized
DEBUG - 2013-01-05 10:02:29 --> No URI present. Default controller set.
DEBUG - 2013-01-05 10:02:29 --> Output Class Initialized
DEBUG - 2013-01-05 10:02:29 --> Security Class Initialized
DEBUG - 2013-01-05 10:02:29 --> Input Class Initialized
DEBUG - 2013-01-05 10:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 10:02:29 --> Language Class Initialized
DEBUG - 2013-01-05 10:02:29 --> Loader Class Initialized
DEBUG - 2013-01-05 10:02:29 --> Helper loaded: url_helper
DEBUG - 2013-01-05 10:02:29 --> Controller Class Initialized
DEBUG - 2013-01-05 10:02:29 --> Model Class Initialized
DEBUG - 2013-01-05 10:02:29 --> Model Class Initialized
DEBUG - 2013-01-05 10:02:29 --> Database Driver Class Initialized
DEBUG - 2013-01-05 10:02:29 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 10:02:29 --> Final output sent to browser
DEBUG - 2013-01-05 10:02:29 --> Total execution time: 0.2068
DEBUG - 2013-01-05 10:03:00 --> Config Class Initialized
DEBUG - 2013-01-05 10:03:00 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:03:00 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:03:00 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:03:00 --> URI Class Initialized
DEBUG - 2013-01-05 10:03:00 --> Router Class Initialized
DEBUG - 2013-01-05 10:03:00 --> Output Class Initialized
DEBUG - 2013-01-05 10:03:00 --> Security Class Initialized
DEBUG - 2013-01-05 10:03:00 --> Input Class Initialized
DEBUG - 2013-01-05 10:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 10:03:00 --> Language Class Initialized
DEBUG - 2013-01-05 10:03:00 --> Loader Class Initialized
DEBUG - 2013-01-05 10:03:00 --> Helper loaded: url_helper
DEBUG - 2013-01-05 10:03:00 --> Controller Class Initialized
DEBUG - 2013-01-05 10:03:00 --> Model Class Initialized
DEBUG - 2013-01-05 10:03:00 --> Model Class Initialized
DEBUG - 2013-01-05 10:03:00 --> Database Driver Class Initialized
DEBUG - 2013-01-05 10:03:00 --> File loaded: application/views/register.php
DEBUG - 2013-01-05 10:03:00 --> Final output sent to browser
DEBUG - 2013-01-05 10:03:00 --> Total execution time: 0.2055
DEBUG - 2013-01-05 10:03:00 --> Config Class Initialized
DEBUG - 2013-01-05 10:03:00 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:03:00 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:03:00 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:03:00 --> URI Class Initialized
DEBUG - 2013-01-05 10:03:00 --> Router Class Initialized
ERROR - 2013-01-05 10:03:00 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-05 10:03:02 --> Config Class Initialized
DEBUG - 2013-01-05 10:03:02 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:03:02 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:03:02 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:03:02 --> URI Class Initialized
DEBUG - 2013-01-05 10:03:02 --> Router Class Initialized
DEBUG - 2013-01-05 10:03:02 --> Output Class Initialized
DEBUG - 2013-01-05 10:03:02 --> Security Class Initialized
DEBUG - 2013-01-05 10:03:02 --> Input Class Initialized
DEBUG - 2013-01-05 10:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 10:03:02 --> Language Class Initialized
DEBUG - 2013-01-05 10:03:02 --> Loader Class Initialized
DEBUG - 2013-01-05 10:03:02 --> Helper loaded: url_helper
DEBUG - 2013-01-05 10:03:02 --> Controller Class Initialized
DEBUG - 2013-01-05 10:03:02 --> Model Class Initialized
DEBUG - 2013-01-05 10:03:02 --> Model Class Initialized
DEBUG - 2013-01-05 10:03:02 --> Database Driver Class Initialized
DEBUG - 2013-01-05 10:03:02 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-05 10:03:02 --> Final output sent to browser
DEBUG - 2013-01-05 10:03:02 --> Total execution time: 0.2170
DEBUG - 2013-01-05 10:03:02 --> Config Class Initialized
DEBUG - 2013-01-05 10:03:02 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:03:02 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:03:02 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:03:02 --> URI Class Initialized
DEBUG - 2013-01-05 10:03:02 --> Router Class Initialized
ERROR - 2013-01-05 10:03:02 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-05 10:03:04 --> Config Class Initialized
DEBUG - 2013-01-05 10:03:04 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:03:04 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:03:04 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:03:04 --> URI Class Initialized
DEBUG - 2013-01-05 10:03:04 --> Router Class Initialized
DEBUG - 2013-01-05 10:03:05 --> Output Class Initialized
DEBUG - 2013-01-05 10:03:05 --> Security Class Initialized
DEBUG - 2013-01-05 10:03:05 --> Input Class Initialized
DEBUG - 2013-01-05 10:03:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 10:03:05 --> Language Class Initialized
DEBUG - 2013-01-05 10:03:05 --> Loader Class Initialized
DEBUG - 2013-01-05 10:03:05 --> Helper loaded: url_helper
DEBUG - 2013-01-05 10:03:05 --> Controller Class Initialized
DEBUG - 2013-01-05 10:03:05 --> Model Class Initialized
DEBUG - 2013-01-05 10:03:05 --> Model Class Initialized
DEBUG - 2013-01-05 10:03:05 --> Database Driver Class Initialized
DEBUG - 2013-01-05 10:03:05 --> File loaded: application/views/register.php
DEBUG - 2013-01-05 10:03:05 --> Final output sent to browser
DEBUG - 2013-01-05 10:03:05 --> Total execution time: 0.2190
DEBUG - 2013-01-05 10:03:05 --> Config Class Initialized
DEBUG - 2013-01-05 10:03:05 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:03:05 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:03:05 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:03:05 --> URI Class Initialized
DEBUG - 2013-01-05 10:03:05 --> Router Class Initialized
ERROR - 2013-01-05 10:03:05 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-05 10:10:26 --> Config Class Initialized
DEBUG - 2013-01-05 10:10:26 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:10:26 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:10:26 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:10:26 --> URI Class Initialized
DEBUG - 2013-01-05 10:10:26 --> Router Class Initialized
DEBUG - 2013-01-05 10:10:26 --> No URI present. Default controller set.
DEBUG - 2013-01-05 10:10:26 --> Output Class Initialized
DEBUG - 2013-01-05 10:10:26 --> Security Class Initialized
DEBUG - 2013-01-05 10:10:26 --> Input Class Initialized
DEBUG - 2013-01-05 10:10:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 10:10:26 --> Language Class Initialized
DEBUG - 2013-01-05 10:10:26 --> Loader Class Initialized
DEBUG - 2013-01-05 10:10:26 --> Helper loaded: url_helper
DEBUG - 2013-01-05 10:10:26 --> Controller Class Initialized
DEBUG - 2013-01-05 10:10:26 --> Model Class Initialized
DEBUG - 2013-01-05 10:10:26 --> Model Class Initialized
DEBUG - 2013-01-05 10:10:26 --> Database Driver Class Initialized
DEBUG - 2013-01-05 10:10:26 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 10:10:26 --> Final output sent to browser
DEBUG - 2013-01-05 10:10:26 --> Total execution time: 0.2299
DEBUG - 2013-01-05 10:10:28 --> Config Class Initialized
DEBUG - 2013-01-05 10:10:28 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:10:28 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:10:28 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:10:28 --> URI Class Initialized
DEBUG - 2013-01-05 10:10:28 --> Router Class Initialized
DEBUG - 2013-01-05 10:10:28 --> Output Class Initialized
DEBUG - 2013-01-05 10:10:28 --> Security Class Initialized
DEBUG - 2013-01-05 10:10:28 --> Input Class Initialized
DEBUG - 2013-01-05 10:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 10:10:28 --> Language Class Initialized
DEBUG - 2013-01-05 10:10:28 --> Loader Class Initialized
DEBUG - 2013-01-05 10:10:28 --> Helper loaded: url_helper
DEBUG - 2013-01-05 10:10:28 --> Controller Class Initialized
DEBUG - 2013-01-05 10:10:28 --> Model Class Initialized
DEBUG - 2013-01-05 10:10:28 --> Model Class Initialized
DEBUG - 2013-01-05 10:10:28 --> Database Driver Class Initialized
DEBUG - 2013-01-05 10:10:28 --> File loaded: application/views/register.php
DEBUG - 2013-01-05 10:10:28 --> Final output sent to browser
DEBUG - 2013-01-05 10:10:28 --> Total execution time: 0.2060
DEBUG - 2013-01-05 10:10:28 --> Config Class Initialized
DEBUG - 2013-01-05 10:10:28 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:10:28 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:10:28 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:10:28 --> URI Class Initialized
DEBUG - 2013-01-05 10:10:28 --> Router Class Initialized
ERROR - 2013-01-05 10:10:28 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-05 10:10:39 --> Config Class Initialized
DEBUG - 2013-01-05 10:10:39 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:10:39 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:10:39 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:10:39 --> URI Class Initialized
DEBUG - 2013-01-05 10:10:39 --> Router Class Initialized
DEBUG - 2013-01-05 10:10:39 --> Output Class Initialized
DEBUG - 2013-01-05 10:10:39 --> Security Class Initialized
DEBUG - 2013-01-05 10:10:39 --> Input Class Initialized
DEBUG - 2013-01-05 10:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 10:10:39 --> Language Class Initialized
DEBUG - 2013-01-05 10:10:39 --> Loader Class Initialized
DEBUG - 2013-01-05 10:10:39 --> Helper loaded: url_helper
DEBUG - 2013-01-05 10:10:39 --> Controller Class Initialized
DEBUG - 2013-01-05 10:10:39 --> Model Class Initialized
DEBUG - 2013-01-05 10:10:39 --> Model Class Initialized
DEBUG - 2013-01-05 10:10:39 --> Database Driver Class Initialized
DEBUG - 2013-01-05 10:10:39 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-05 10:10:39 --> Final output sent to browser
DEBUG - 2013-01-05 10:10:39 --> Total execution time: 0.2153
DEBUG - 2013-01-05 10:10:39 --> Config Class Initialized
DEBUG - 2013-01-05 10:10:39 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:10:39 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:10:39 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:10:39 --> URI Class Initialized
DEBUG - 2013-01-05 10:10:39 --> Router Class Initialized
ERROR - 2013-01-05 10:10:39 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-05 10:10:50 --> Config Class Initialized
DEBUG - 2013-01-05 10:10:50 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:10:50 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:10:50 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:10:50 --> URI Class Initialized
DEBUG - 2013-01-05 10:10:50 --> Router Class Initialized
DEBUG - 2013-01-05 10:10:50 --> No URI present. Default controller set.
DEBUG - 2013-01-05 10:10:50 --> Output Class Initialized
DEBUG - 2013-01-05 10:10:50 --> Security Class Initialized
DEBUG - 2013-01-05 10:10:50 --> Input Class Initialized
DEBUG - 2013-01-05 10:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 10:10:50 --> Language Class Initialized
DEBUG - 2013-01-05 10:10:50 --> Loader Class Initialized
DEBUG - 2013-01-05 10:10:50 --> Helper loaded: url_helper
DEBUG - 2013-01-05 10:10:50 --> Controller Class Initialized
DEBUG - 2013-01-05 10:10:50 --> Model Class Initialized
DEBUG - 2013-01-05 10:10:50 --> Model Class Initialized
DEBUG - 2013-01-05 10:10:50 --> Database Driver Class Initialized
DEBUG - 2013-01-05 10:10:50 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 10:10:50 --> Final output sent to browser
DEBUG - 2013-01-05 10:10:50 --> Total execution time: 0.2846
DEBUG - 2013-01-05 10:11:05 --> Config Class Initialized
DEBUG - 2013-01-05 10:11:05 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:11:05 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:11:05 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:11:05 --> URI Class Initialized
DEBUG - 2013-01-05 10:11:05 --> Router Class Initialized
DEBUG - 2013-01-05 10:11:05 --> No URI present. Default controller set.
DEBUG - 2013-01-05 10:11:05 --> Output Class Initialized
DEBUG - 2013-01-05 10:11:05 --> Security Class Initialized
DEBUG - 2013-01-05 10:11:05 --> Input Class Initialized
DEBUG - 2013-01-05 10:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 10:11:05 --> Language Class Initialized
DEBUG - 2013-01-05 10:11:05 --> Loader Class Initialized
DEBUG - 2013-01-05 10:11:05 --> Helper loaded: url_helper
DEBUG - 2013-01-05 10:11:05 --> Controller Class Initialized
DEBUG - 2013-01-05 10:11:05 --> Model Class Initialized
DEBUG - 2013-01-05 10:11:05 --> Model Class Initialized
DEBUG - 2013-01-05 10:11:05 --> Database Driver Class Initialized
DEBUG - 2013-01-05 10:11:05 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 10:11:05 --> Final output sent to browser
DEBUG - 2013-01-05 10:11:05 --> Total execution time: 0.2997
DEBUG - 2013-01-05 10:11:08 --> Config Class Initialized
DEBUG - 2013-01-05 10:11:08 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:11:08 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:11:08 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:11:08 --> URI Class Initialized
DEBUG - 2013-01-05 10:11:08 --> Router Class Initialized
DEBUG - 2013-01-05 10:11:08 --> Output Class Initialized
DEBUG - 2013-01-05 10:11:08 --> Security Class Initialized
DEBUG - 2013-01-05 10:11:08 --> Input Class Initialized
DEBUG - 2013-01-05 10:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 10:11:08 --> Language Class Initialized
DEBUG - 2013-01-05 10:11:08 --> Loader Class Initialized
DEBUG - 2013-01-05 10:11:08 --> Helper loaded: url_helper
DEBUG - 2013-01-05 10:11:08 --> Controller Class Initialized
DEBUG - 2013-01-05 10:11:08 --> Model Class Initialized
DEBUG - 2013-01-05 10:11:08 --> Model Class Initialized
DEBUG - 2013-01-05 10:11:08 --> Database Driver Class Initialized
DEBUG - 2013-01-05 10:11:08 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-05 10:11:08 --> Final output sent to browser
DEBUG - 2013-01-05 10:11:08 --> Total execution time: 0.2101
DEBUG - 2013-01-05 10:11:08 --> Config Class Initialized
DEBUG - 2013-01-05 10:11:08 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:11:08 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:11:08 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:11:08 --> URI Class Initialized
DEBUG - 2013-01-05 10:11:08 --> Router Class Initialized
ERROR - 2013-01-05 10:11:08 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-05 10:11:37 --> Config Class Initialized
DEBUG - 2013-01-05 10:11:37 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:11:37 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:11:37 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:11:37 --> URI Class Initialized
DEBUG - 2013-01-05 10:11:37 --> Router Class Initialized
DEBUG - 2013-01-05 10:11:37 --> Output Class Initialized
DEBUG - 2013-01-05 10:11:37 --> Security Class Initialized
DEBUG - 2013-01-05 10:11:37 --> Input Class Initialized
DEBUG - 2013-01-05 10:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 10:11:37 --> Language Class Initialized
DEBUG - 2013-01-05 10:11:37 --> Loader Class Initialized
DEBUG - 2013-01-05 10:11:37 --> Helper loaded: url_helper
DEBUG - 2013-01-05 10:11:37 --> Controller Class Initialized
DEBUG - 2013-01-05 10:11:37 --> Model Class Initialized
DEBUG - 2013-01-05 10:11:37 --> Model Class Initialized
DEBUG - 2013-01-05 10:11:37 --> Database Driver Class Initialized
DEBUG - 2013-01-05 10:11:37 --> Final output sent to browser
DEBUG - 2013-01-05 10:11:37 --> Total execution time: 0.4045
DEBUG - 2013-01-05 10:12:17 --> Config Class Initialized
DEBUG - 2013-01-05 10:12:17 --> Hooks Class Initialized
DEBUG - 2013-01-05 10:12:17 --> Utf8 Class Initialized
DEBUG - 2013-01-05 10:12:17 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 10:12:17 --> URI Class Initialized
DEBUG - 2013-01-05 10:12:17 --> Router Class Initialized
DEBUG - 2013-01-05 10:12:17 --> No URI present. Default controller set.
DEBUG - 2013-01-05 10:12:17 --> Output Class Initialized
DEBUG - 2013-01-05 10:12:17 --> Security Class Initialized
DEBUG - 2013-01-05 10:12:17 --> Input Class Initialized
DEBUG - 2013-01-05 10:12:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 10:12:17 --> Language Class Initialized
DEBUG - 2013-01-05 10:12:17 --> Loader Class Initialized
DEBUG - 2013-01-05 10:12:17 --> Helper loaded: url_helper
DEBUG - 2013-01-05 10:12:17 --> Controller Class Initialized
DEBUG - 2013-01-05 10:12:17 --> Model Class Initialized
DEBUG - 2013-01-05 10:12:17 --> Model Class Initialized
DEBUG - 2013-01-05 10:12:17 --> Database Driver Class Initialized
DEBUG - 2013-01-05 10:12:17 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 10:12:17 --> Final output sent to browser
DEBUG - 2013-01-05 10:12:17 --> Total execution time: 0.2266
DEBUG - 2013-01-05 14:17:58 --> Config Class Initialized
DEBUG - 2013-01-05 14:17:58 --> Hooks Class Initialized
DEBUG - 2013-01-05 14:17:58 --> Utf8 Class Initialized
DEBUG - 2013-01-05 14:17:58 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 14:17:58 --> URI Class Initialized
DEBUG - 2013-01-05 14:17:58 --> Router Class Initialized
DEBUG - 2013-01-05 14:17:58 --> No URI present. Default controller set.
DEBUG - 2013-01-05 14:17:58 --> Output Class Initialized
DEBUG - 2013-01-05 14:17:58 --> Security Class Initialized
DEBUG - 2013-01-05 14:17:58 --> Input Class Initialized
DEBUG - 2013-01-05 14:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 14:17:58 --> Language Class Initialized
DEBUG - 2013-01-05 14:17:58 --> Loader Class Initialized
DEBUG - 2013-01-05 14:17:58 --> Helper loaded: url_helper
DEBUG - 2013-01-05 14:17:58 --> Controller Class Initialized
DEBUG - 2013-01-05 14:17:59 --> Model Class Initialized
DEBUG - 2013-01-05 14:17:59 --> Model Class Initialized
DEBUG - 2013-01-05 14:17:59 --> Database Driver Class Initialized
DEBUG - 2013-01-05 14:17:59 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 14:17:59 --> Final output sent to browser
DEBUG - 2013-01-05 14:17:59 --> Total execution time: 0.7173
DEBUG - 2013-01-05 14:18:01 --> Config Class Initialized
DEBUG - 2013-01-05 14:18:01 --> Hooks Class Initialized
DEBUG - 2013-01-05 14:18:01 --> Utf8 Class Initialized
DEBUG - 2013-01-05 14:18:01 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 14:18:01 --> URI Class Initialized
DEBUG - 2013-01-05 14:18:01 --> Router Class Initialized
DEBUG - 2013-01-05 14:18:01 --> Output Class Initialized
DEBUG - 2013-01-05 14:18:01 --> Security Class Initialized
DEBUG - 2013-01-05 14:18:01 --> Input Class Initialized
DEBUG - 2013-01-05 14:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 14:18:01 --> Language Class Initialized
DEBUG - 2013-01-05 14:18:01 --> Loader Class Initialized
DEBUG - 2013-01-05 14:18:01 --> Helper loaded: url_helper
DEBUG - 2013-01-05 14:18:01 --> Controller Class Initialized
DEBUG - 2013-01-05 14:18:01 --> Model Class Initialized
DEBUG - 2013-01-05 14:18:01 --> Model Class Initialized
DEBUG - 2013-01-05 14:18:01 --> Database Driver Class Initialized
DEBUG - 2013-01-05 14:18:01 --> File loaded: application/views/register.php
DEBUG - 2013-01-05 14:18:01 --> Final output sent to browser
DEBUG - 2013-01-05 14:18:01 --> Total execution time: 0.2786
DEBUG - 2013-01-05 14:18:01 --> Config Class Initialized
DEBUG - 2013-01-05 14:18:01 --> Hooks Class Initialized
DEBUG - 2013-01-05 14:18:01 --> Utf8 Class Initialized
DEBUG - 2013-01-05 14:18:01 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 14:18:01 --> URI Class Initialized
DEBUG - 2013-01-05 14:18:01 --> Router Class Initialized
ERROR - 2013-01-05 14:18:01 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-05 14:18:03 --> Config Class Initialized
DEBUG - 2013-01-05 14:18:03 --> Hooks Class Initialized
DEBUG - 2013-01-05 14:18:03 --> Utf8 Class Initialized
DEBUG - 2013-01-05 14:18:03 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 14:18:03 --> URI Class Initialized
DEBUG - 2013-01-05 14:18:03 --> Router Class Initialized
DEBUG - 2013-01-05 14:18:03 --> Output Class Initialized
DEBUG - 2013-01-05 14:18:03 --> Security Class Initialized
DEBUG - 2013-01-05 14:18:03 --> Input Class Initialized
DEBUG - 2013-01-05 14:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 14:18:04 --> Language Class Initialized
DEBUG - 2013-01-05 14:18:04 --> Loader Class Initialized
DEBUG - 2013-01-05 14:18:04 --> Helper loaded: url_helper
DEBUG - 2013-01-05 14:18:04 --> Controller Class Initialized
DEBUG - 2013-01-05 14:18:04 --> Model Class Initialized
DEBUG - 2013-01-05 14:18:04 --> Model Class Initialized
DEBUG - 2013-01-05 14:18:04 --> Database Driver Class Initialized
DEBUG - 2013-01-05 14:18:04 --> File loaded: application/views/update_balance.php
DEBUG - 2013-01-05 14:18:04 --> Final output sent to browser
DEBUG - 2013-01-05 14:18:04 --> Total execution time: 0.2771
DEBUG - 2013-01-05 14:18:04 --> Config Class Initialized
DEBUG - 2013-01-05 14:18:04 --> Hooks Class Initialized
DEBUG - 2013-01-05 14:18:04 --> Utf8 Class Initialized
DEBUG - 2013-01-05 14:18:04 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 14:18:04 --> URI Class Initialized
DEBUG - 2013-01-05 14:18:04 --> Router Class Initialized
ERROR - 2013-01-05 14:18:04 --> 404 Page Not Found --> getExcel
DEBUG - 2013-01-05 14:18:11 --> Config Class Initialized
DEBUG - 2013-01-05 14:18:11 --> Hooks Class Initialized
DEBUG - 2013-01-05 14:18:11 --> Utf8 Class Initialized
DEBUG - 2013-01-05 14:18:11 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 14:18:11 --> URI Class Initialized
DEBUG - 2013-01-05 14:18:11 --> Router Class Initialized
DEBUG - 2013-01-05 14:18:11 --> Output Class Initialized
DEBUG - 2013-01-05 14:18:11 --> Security Class Initialized
DEBUG - 2013-01-05 14:18:11 --> Input Class Initialized
DEBUG - 2013-01-05 14:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 14:18:11 --> Language Class Initialized
DEBUG - 2013-01-05 14:18:11 --> Loader Class Initialized
DEBUG - 2013-01-05 14:18:11 --> Helper loaded: url_helper
DEBUG - 2013-01-05 14:18:11 --> Controller Class Initialized
DEBUG - 2013-01-05 14:18:11 --> Model Class Initialized
DEBUG - 2013-01-05 14:18:11 --> Model Class Initialized
DEBUG - 2013-01-05 14:18:11 --> Database Driver Class Initialized
DEBUG - 2013-01-05 14:18:11 --> Final output sent to browser
DEBUG - 2013-01-05 14:18:11 --> Total execution time: 0.6509
DEBUG - 2013-01-05 14:18:21 --> Config Class Initialized
DEBUG - 2013-01-05 14:18:21 --> Hooks Class Initialized
DEBUG - 2013-01-05 14:18:21 --> Utf8 Class Initialized
DEBUG - 2013-01-05 14:18:21 --> UTF-8 Support Enabled
DEBUG - 2013-01-05 14:18:21 --> URI Class Initialized
DEBUG - 2013-01-05 14:18:21 --> Router Class Initialized
DEBUG - 2013-01-05 14:18:21 --> No URI present. Default controller set.
DEBUG - 2013-01-05 14:18:22 --> Output Class Initialized
DEBUG - 2013-01-05 14:18:22 --> Security Class Initialized
DEBUG - 2013-01-05 14:18:22 --> Input Class Initialized
DEBUG - 2013-01-05 14:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-05 14:18:22 --> Language Class Initialized
DEBUG - 2013-01-05 14:18:22 --> Loader Class Initialized
DEBUG - 2013-01-05 14:18:22 --> Helper loaded: url_helper
DEBUG - 2013-01-05 14:18:22 --> Controller Class Initialized
DEBUG - 2013-01-05 14:18:22 --> Model Class Initialized
DEBUG - 2013-01-05 14:18:22 --> Model Class Initialized
DEBUG - 2013-01-05 14:18:22 --> Database Driver Class Initialized
DEBUG - 2013-01-05 14:18:22 --> File loaded: application/views/home.php
DEBUG - 2013-01-05 14:18:22 --> Final output sent to browser
DEBUG - 2013-01-05 14:18:22 --> Total execution time: 0.2445

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-07-24 02:35:00 --> Config Class Initialized
DEBUG - 2016-07-24 02:35:00 --> Hooks Class Initialized
DEBUG - 2016-07-24 02:35:00 --> Utf8 Class Initialized
DEBUG - 2016-07-24 02:35:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-24 02:35:00 --> URI Class Initialized
DEBUG - 2016-07-24 02:35:00 --> Router Class Initialized
DEBUG - 2016-07-24 02:35:00 --> No URI present. Default controller set.
DEBUG - 2016-07-24 02:35:00 --> Output Class Initialized
DEBUG - 2016-07-24 02:35:00 --> Security Class Initialized
DEBUG - 2016-07-24 02:35:00 --> Input Class Initialized
DEBUG - 2016-07-24 02:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-24 02:35:00 --> Language Class Initialized
DEBUG - 2016-07-24 02:35:00 --> Loader Class Initialized
DEBUG - 2016-07-24 02:35:00 --> Helper loaded: url_helper
DEBUG - 2016-07-24 02:35:00 --> Controller Class Initialized
DEBUG - 2016-07-24 02:35:00 --> Model Class Initialized
DEBUG - 2016-07-24 02:35:00 --> Model Class Initialized
DEBUG - 2016-07-24 02:35:00 --> Database Driver Class Initialized
ERROR - 2016-07-24 02:35:00 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/a8807195/public_html/webservice/mobiba_service/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-07-24 02:35:00 --> Unable to connect to the database
DEBUG - 2016-07-24 02:35:00 --> File loaded: application/views/home.php
DEBUG - 2016-07-24 02:35:00 --> Final output sent to browser
DEBUG - 2016-07-24 02:35:00 --> Total execution time: 0.1036
ERROR - 2016-07-24 02:35:00 --> Severity: Notice  --> Undefined variable: c_ads /usr/local/lib/php/foot.php 4

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-12-31 00:43:13 --> Config Class Initialized
DEBUG - 2016-12-31 00:43:13 --> Hooks Class Initialized
DEBUG - 2016-12-31 00:43:13 --> Utf8 Class Initialized
DEBUG - 2016-12-31 00:43:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-31 00:43:13 --> URI Class Initialized
DEBUG - 2016-12-31 00:43:13 --> Router Class Initialized
DEBUG - 2016-12-31 00:43:13 --> No URI present. Default controller set.
DEBUG - 2016-12-31 00:43:13 --> Output Class Initialized
DEBUG - 2016-12-31 00:43:13 --> Security Class Initialized
DEBUG - 2016-12-31 00:43:13 --> Input Class Initialized
DEBUG - 2016-12-31 00:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-31 00:43:13 --> Language Class Initialized
DEBUG - 2016-12-31 00:43:13 --> Loader Class Initialized
DEBUG - 2016-12-31 00:43:13 --> Helper loaded: url_helper
DEBUG - 2016-12-31 00:43:13 --> Controller Class Initialized
DEBUG - 2016-12-31 00:43:13 --> Model Class Initialized
DEBUG - 2016-12-31 00:43:13 --> Model Class Initialized
DEBUG - 2016-12-31 00:43:13 --> Database Driver Class Initialized
ERROR - 2016-12-31 00:43:13 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/a8807195/public_html/webservice/mobiba_service/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-12-31 00:43:13 --> Unable to connect to the database
DEBUG - 2016-12-31 00:43:13 --> File loaded: application/views/home.php
DEBUG - 2016-12-31 00:43:13 --> Final output sent to browser
DEBUG - 2016-12-31 00:43:13 --> Total execution time: 0.0907
ERROR - 2016-12-31 00:43:13 --> Severity: Notice  --> Undefined variable: c_ads /usr/local/lib/php/foot.php 4

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-08-28 05:13:14 --> Config Class Initialized
DEBUG - 2016-08-28 05:13:14 --> Hooks Class Initialized
DEBUG - 2016-08-28 05:13:14 --> Utf8 Class Initialized
DEBUG - 2016-08-28 05:13:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-28 05:13:14 --> URI Class Initialized
DEBUG - 2016-08-28 05:13:14 --> Router Class Initialized
DEBUG - 2016-08-28 05:13:14 --> No URI present. Default controller set.
DEBUG - 2016-08-28 05:13:14 --> Output Class Initialized
DEBUG - 2016-08-28 05:13:14 --> Security Class Initialized
DEBUG - 2016-08-28 05:13:14 --> Input Class Initialized
DEBUG - 2016-08-28 05:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-28 05:13:14 --> Language Class Initialized
DEBUG - 2016-08-28 05:13:14 --> Loader Class Initialized
DEBUG - 2016-08-28 05:13:14 --> Helper loaded: url_helper
DEBUG - 2016-08-28 05:13:14 --> Controller Class Initialized
DEBUG - 2016-08-28 05:13:14 --> Model Class Initialized
DEBUG - 2016-08-28 05:13:14 --> Model Class Initialized
DEBUG - 2016-08-28 05:13:14 --> Database Driver Class Initialized
ERROR - 2016-08-28 05:13:14 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/a8807195/public_html/webservice/mobiba_service/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-08-28 05:13:14 --> Unable to connect to the database
DEBUG - 2016-08-28 05:13:14 --> File loaded: application/views/home.php
DEBUG - 2016-08-28 05:13:14 --> Final output sent to browser
DEBUG - 2016-08-28 05:13:14 --> Total execution time: 0.1111
ERROR - 2016-08-28 05:13:14 --> Severity: Notice  --> Undefined variable: c_ads /usr/local/lib/php/foot.php 4

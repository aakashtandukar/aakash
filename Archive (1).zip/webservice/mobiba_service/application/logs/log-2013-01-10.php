<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-01-10 15:51:13 --> Config Class Initialized
DEBUG - 2013-01-10 15:51:13 --> Hooks Class Initialized
DEBUG - 2013-01-10 15:51:13 --> Utf8 Class Initialized
DEBUG - 2013-01-10 15:51:13 --> UTF-8 Support Enabled
DEBUG - 2013-01-10 15:51:13 --> URI Class Initialized
DEBUG - 2013-01-10 15:51:13 --> Router Class Initialized
DEBUG - 2013-01-10 15:51:13 --> No URI present. Default controller set.
DEBUG - 2013-01-10 15:51:13 --> Output Class Initialized
DEBUG - 2013-01-10 15:51:13 --> Security Class Initialized
DEBUG - 2013-01-10 15:51:13 --> Input Class Initialized
DEBUG - 2013-01-10 15:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-10 15:51:13 --> Language Class Initialized
DEBUG - 2013-01-10 15:51:14 --> Loader Class Initialized
DEBUG - 2013-01-10 15:51:14 --> Helper loaded: url_helper
DEBUG - 2013-01-10 15:51:14 --> Controller Class Initialized
DEBUG - 2013-01-10 15:51:14 --> Model Class Initialized
DEBUG - 2013-01-10 15:51:14 --> Model Class Initialized
DEBUG - 2013-01-10 15:51:14 --> Database Driver Class Initialized
DEBUG - 2013-01-10 15:51:14 --> File loaded: application/views/home.php
DEBUG - 2013-01-10 15:51:14 --> Final output sent to browser
DEBUG - 2013-01-10 15:51:14 --> Total execution time: 1.2636

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-11-20 13:06:29 --> Config Class Initialized
DEBUG - 2016-11-20 13:06:29 --> Hooks Class Initialized
DEBUG - 2016-11-20 13:06:29 --> Utf8 Class Initialized
DEBUG - 2016-11-20 13:06:29 --> UTF-8 Support Enabled
DEBUG - 2016-11-20 13:06:29 --> URI Class Initialized
DEBUG - 2016-11-20 13:06:29 --> Router Class Initialized
DEBUG - 2016-11-20 13:06:29 --> No URI present. Default controller set.
DEBUG - 2016-11-20 13:06:29 --> Output Class Initialized
DEBUG - 2016-11-20 13:06:29 --> Security Class Initialized
DEBUG - 2016-11-20 13:06:29 --> Input Class Initialized
DEBUG - 2016-11-20 13:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-20 13:06:29 --> Language Class Initialized
DEBUG - 2016-11-20 13:06:29 --> Loader Class Initialized
DEBUG - 2016-11-20 13:06:29 --> Helper loaded: url_helper
DEBUG - 2016-11-20 13:06:29 --> Controller Class Initialized
DEBUG - 2016-11-20 13:06:29 --> Model Class Initialized
DEBUG - 2016-11-20 13:06:29 --> Model Class Initialized
DEBUG - 2016-11-20 13:06:29 --> Database Driver Class Initialized
ERROR - 2016-11-20 13:06:29 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/a8807195/public_html/webservice/mobiba_service/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-11-20 13:06:29 --> Unable to connect to the database
DEBUG - 2016-11-20 13:06:29 --> File loaded: application/views/home.php
DEBUG - 2016-11-20 13:06:29 --> Final output sent to browser
DEBUG - 2016-11-20 13:06:29 --> Total execution time: 0.0918
DEBUG - 2016-11-20 14:18:15 --> Config Class Initialized
DEBUG - 2016-11-20 14:18:15 --> Hooks Class Initialized
DEBUG - 2016-11-20 14:18:15 --> Utf8 Class Initialized
DEBUG - 2016-11-20 14:18:15 --> UTF-8 Support Enabled
DEBUG - 2016-11-20 14:18:15 --> URI Class Initialized
DEBUG - 2016-11-20 14:18:15 --> Router Class Initialized
DEBUG - 2016-11-20 14:18:15 --> No URI present. Default controller set.
DEBUG - 2016-11-20 14:18:15 --> Output Class Initialized
DEBUG - 2016-11-20 14:18:15 --> Security Class Initialized
DEBUG - 2016-11-20 14:18:15 --> Input Class Initialized
DEBUG - 2016-11-20 14:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-20 14:18:15 --> Language Class Initialized
DEBUG - 2016-11-20 14:18:15 --> Loader Class Initialized
DEBUG - 2016-11-20 14:18:15 --> Helper loaded: url_helper
DEBUG - 2016-11-20 14:18:15 --> Controller Class Initialized
DEBUG - 2016-11-20 14:18:15 --> Model Class Initialized
DEBUG - 2016-11-20 14:18:15 --> Model Class Initialized
DEBUG - 2016-11-20 14:18:15 --> Database Driver Class Initialized
ERROR - 2016-11-20 14:18:15 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/a8807195/public_html/webservice/mobiba_service/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-11-20 14:18:15 --> Unable to connect to the database
DEBUG - 2016-11-20 14:18:15 --> File loaded: application/views/home.php
DEBUG - 2016-11-20 14:18:15 --> Final output sent to browser
DEBUG - 2016-11-20 14:18:15 --> Total execution time: 0.0252
